# -*- coding: utf-8 -*-

import urllib
import urlparse


def utf8(s):
    '''Convert str or unicode to UTF-8 str'''
    if isinstance(s, unicode):
        s = s.encode('utf8')
    elif isinstance(s, str):
        # Must be encoded in UTF-8, no result but only check
        s.decode('utf8')  # can raise UnicodeDecodeError
    return s


def urlencode(in_dict):
    '''Encode dict to URL string'''
    out_dict = {}
    for k, v in in_dict.iteritems():
        out_dict[k] = utf8(v)
    return urllib.urlencode(out_dict)


def urldecode(paramstring):
    '''Decode URL string to dict'''
    print "urldecode --> paramstring: " + repr(paramstring)
    if paramstring.startswith('?'):
        print "wnat param string1: " + repr(paramstring)
        paramstring = paramstring[1:]

        print "what param string2: " + repr(paramstring)
        print "what param string3:  " + repr(urlparse.parse_qsl(paramstring))
        print "what param string4:  " + repr(dict(urlparse.parse_qsl(paramstring)))
        print "hmm: "+ paramstring[paramstring.find('url='):]
    return dict(urlparse.parse_qsl(paramstring))  # returns normal dict, ignores duplicates
    #return urlparse.parse_qs(paramstring)  # returns dict with keys and LIST of values

def urldecode2url(paramstring):
    '''Decode URL string to dict'''
    if paramstring.startswith('?'):
        print "wnat param string1: " + repr(paramstring)
        paramstring = paramstring[1:]
        urlpos=paramstring.find('url=')
        trueurl=paramstring[urlpos+4:]
        paramstring = paramstring[0:urlpos-1]
        newdict = dict(urlparse.parse_qsl(paramstring))
        newdict['trueurl']= trueurl
        print "dec2:what param string2: " + repr(paramstring)
        print "dec2:what param string3:  " + repr(urlparse.parse_qsl(paramstring))
        print "dec2:what param string4:  " + repr(dict(urlparse.parse_qsl(paramstring)))
        print "dec2:hmm: "+ paramstring[paramstring.find('url='):]

    return newdict  # returns normal dict, ignores duplicates

