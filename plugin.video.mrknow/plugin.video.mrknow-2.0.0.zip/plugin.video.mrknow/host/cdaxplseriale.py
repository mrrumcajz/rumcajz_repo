# -*- coding: utf-8 -*-

'''
    plugin.video.mrknow XBMC Addon
    Copyright (C) 2017 mrknow

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
'''
import sys, urlparse, os
import re
from __generic_host__ import GenericHost
import HTMLParser
import xbmcgui
import urllib

from __generic_host__ import GenericHost
from search import Search


mainUrl = 'https://cda-x.pl/'
filmUrl = 'https://cda-x.pl/seriale/'
#catUrl = 'https://cda-x.pl/filmy-online/category:%s/?page=1'
#lastUrl = 'https://cda-x.pl/filmy/'
#szukajUrl = 'http://alltube.tv/szukaj'

class cdaxplseriale(GenericHost):

    scriptname = 'cdaxplseriale'
    host = 'cdaxplseriale'
    MENU_TAB = [
        {'id': 1, 'title': 'Polecane', 'mod': 'Polecane'},
        {'id': 10, 'title': 'Kategorie', 'mod': 'Kategorie'},
        {'id': 20, 'title': 'Rok', 'mod': 'Rok'},
        #{'id': 30, 'title': 'Alfabetycznie', 'mod': 'Alfabetycznie'},
         #{'id': 4, 'title': 'Szukaj', 'mod': 'find', },
        #{'id': 5, 'title': 'Historia wyszukiwania', 'mod': 'history'},
        # {'id': 3, 'title': 'Bajki', 'mod': 'ListBajki', },
        # {'id': 3, 'title': 'Bajki', 'mod': 'ListBajki', },


    ]

    #search = Search(url='%(quoted)s', service='alltubefilmy', listItemsFun=self.listsItemsOther)

#    def listsCategoriesMenu(self):
#        result = self.client.request(filmUrl)
#        r = self.client.parseDOM(result, 'nav', {"class": "genres"})
#        href=self.client.parseDOM(r,'a',ret='href')
#        genre=self.client.parseDOM(r,'a')
#        #r = [(self.client.parseDOM(r, 'li'), self.client.parseDOM(r, 'li', ret='data-id'))]
#        #r = [(self.client.parseDOM(r[0][0][i], 'a')[0],r[0][1][i]) for i,j in enumerate(r[0][0])]
#        for i in range(0, len(genre)):
#            self.control.log('%s' % str(i))
#            #myurl = catUrl  % i[1]
#            myurl = href[i]
#            self.add(self.host, 'categories-menu', genre[i],genre[i],  'None', myurl, True, False)
#
#        #xbmcplugin.endOfDirectory(int(sys.argv[1]))
#        self.control.directory(int(sys.argv[1]))

    def listsAlphabetMenu(self):
        result = self.client.request(filmUrl)

        print "alfabet: ", repr(result)
        r = self.client.parseDOM(result, 'div', {"class": "letter_home"})
        alfabet=self.client.parseDOM(r,'a')
        #href=self.client.parseDOM(r,'a',ret='href')
        #years=self.client.parseDOM(r,'a')
        #r = [(self.client.parseDOM(r, 'li'), self.client.parseDOM(r, 'li', ret='data-id'))]
        #r = [(self.client.parseDOM(r[0][0][i], 'a')[0],r[0][1][i]) for i,j in enumerate(r[0][0])]
        for i in range(0, len(alfabet)):
            self.control.log('%s' % str(i))
        #    #myurl = catUrl  % i[1]
            myurl = filUrl
            self.add(self.host, 'categories-menu', alfabet[i],alfabet[i],  'None', myurl, True, False)
        #xbmcplugin.endOfDirectory(int(sys.argv[1]))
        self.control.directory(int(sys.argv[1]))

#    def listsYearMenu(self):
#        result = self.client.request(filmUrl)
#        r = self.client.parseDOM(result, 'nav', {"class": "releases"})
#        href=self.client.parseDOM(r,'a',ret='href')
#        years=self.client.parseDOM(r,'a')
#        #r = [(self.client.parseDOM(r, 'li'), self.client.parseDOM(r, 'li', ret='data-id'))]
#        #r = [(self.client.parseDOM(r[0][0][i], 'a')[0],r[0][1][i]) for i,j in enumerate(r[0][0])]
#        for i in range(0, len(years)):
#            self.control.log('%s' % str(i))
#            #myurl = catUrl  % i[1]
#            myurl = href[i]
#            self.add(self.host, 'categories-menu', years[i],years[i],  'None', myurl, True, False)
#        #xbmcplugin.endOfDirectory(int(sys.argv[1]))
#        self.control.directory(int(sys.argv[1]))


    def listsSearchResults(self, key):
        self.control.log(key)
        post_data = {'search': key}
        result = self.s.post(szukajUrl, data=post_data).text
        #self.control.log('ALA %s' % result.encode('utf-8'))
        try:
            result = re.findall('<h2 class="headline">Filmy</h2>(.*)<h2 class="headline">Seriale</h2>', result, re.DOTALL)[0]
            r = self.client.parseDOM(result, 'div', attrs={'class':'item-block clearfix'})
            r = [(self.client.parseDOM(i, 'a', ret='href'),
                  self.client.parseDOM(i, 'img', ret='src'),
                  self.client.parseDOM(i, 'h3'),
                  self.client.parseDOM(i, 'p')) for i in r]
            for i in r:
                self.control.log('ALA %s' % str(i))
                 # self.control.log('%s' % str(i) )
                try:
                    # self.control.log('AAA %s' % str(i))
                    meta = {'title': i[2][0], 'poster': i[1][0], 'year': '','plot': i[3][0]}
                    meta['originaltitle'] = i[2][0].encode('utf-8')
                    params = {'service': self.host, 'name': 'playselectedmovie', 'category': '', 'isplayable': 'true',
                              'url': i[0][0]}
                    params.update(meta)
                    self.add2(params)
                except Exception as e:
                    self.control.log('EEEEEEEEERRRTOO %s' % e)
                    pass
        except:
            pass
        self.dirend(int(sys.argv[1]))

    def listsItems(self, url):
        try:
            mypagenumber = re.findall('=(\d+)',url)[0]
            page = int(mypagenumber)
        except:
            page = 1
        self.control.log('[]1 %s' % url)
        self.control.log('[]1 %s' % page)
       # mynext = url.replace('='+str(page), '='+str(page+1))
       # self.control.log('[]2 %s' % mynext)

        #link = self.client.request(url)
        result = self.request(url, utf=False)
        print "Strona: ",repr(result)
        tst = self.client.parseDOM(result,'div', attrs={"id": "featured-titles"})
        print "hmm1: ",repr(tst)
        tst2 = self.client.parseDOM(tst,'article', attrs={"class": "item tvshows"})
        print "hmm: ",repr(tst2)
        for b in range(0, len(tst2)):
            group = {}
            poster =  self.client.parseDOM(tst2[b], "div",attrs={"class": "poster"})
            print "Poster: ",repr(poster)
            image=self.client.parseDOM(poster,'img',ret='src')
            datafeat = self.client.parseDOM(tst2[b],"div",attrs={"class": "data dfeatur"})
            print "Datafeat: ",repr(datafeat)
            title=self.client.parseDOM(datafeat,'a')
            href=self.client.parseDOM(datafeat,'a',ret='href')
            year=self.client.parseDOM(datafeat,'span')

            print "Title: ",title, " img: ",image, " href: ",href

            try:
                meta = {'title': title[0], 'poster': image[0], 'year': year[0],'plot': 'plot', 'orginaltitle':'title'}
                params = {'service': self.host, 'name': 'playselectedmovie', 'category': '','isplayable': 'true','url': href[0]}
                params.update(meta)
                self.add2(params)
            except Exception as e:
                self.control.log('cdaxf-1 ITEM ADD ERROR %s' % e)
                pass
        #r = self.client.parseDOM(result,'div', {"class": "col-xs-6 col-sm-3 col-lg-3"})
        #r = [(self.client.parseDOM(i, 'a', ret='href'),self.client.parseDOM(i, 'img', ret='src'),
        #      self.client.parseDOM(i, 'a', ret='data-content'),self.client.parseDOM(i, 'div', attrs={'class': 'year'}),
        #      self.client.parseDOM(i, 'div', attrs={'class': 'title'})) for i in r]

        #for i in r:
        #    self.control.log('%s' % str(i))
        #    try:
        #        tite = i[4][0].split('/')[1]
        #        titp = i[4][0].split('/')[0]
        #    except:
        #        tite = i[4][0]
        #        titp = i[4][0]
        #    try:
        #        meta = {'title': titp, 'poster': i[1][0], 'year': i[3][0],'plot': i[2][0], 'orginaltitle':tite}
        #        params = {'service': self.host, 'name': 'playselectedmovie', 'category': '','isplayable': 'true','url': i[0][0]}
        #        params.update(meta)
        #        self.add2(params)
        #    except Exception as e:
        #        self.control.log('cdaxf-1 ITEM ADD ERROR %s' % e)
        #        pass

        #self.add(self.host, 'categories-menu', u'Następna strona',u'Następna strona',  'None', mynext, True, False)
        self.dirend(int(sys.argv[1]))

    def listsItems2(self, url):
        result = self.request(url, utf=False)
        try:
            pagestrona=self.client.parseDOM(result,'div',attrs={"class": "pagination"})
            mypage=self.client.parseDOM(result,'span',attrs={"class": "current"})
            #mypagenumber = re.findall('=(\d+)',url)[0]
            page = int(mypage[0])
        except:
            page = 1
        self.control.log('[]1 %s' % url)
        self.control.log('[]1 %s' % page)

        if re.search('page',url):
            mynext=url.replace('/'+str(page), '/'+str(page+1))
        else:
            mynext = url + "page/"+str(page+1)+"/"
            print "nexturl: ",repr(mynext)
       # self.control.log('[]2 %s' % mynext)

        #link = self.client.request(url)
        #result = self.request(url, utf=False)
        print "Strona: ",repr(result)
        tst = self.client.parseDOM(result,'div', attrs={"class": "items"})
        print "hmm1: ",repr(tst)
        tst2 = self.client.parseDOM(tst,'article', attrs={"class": "item movies"})
        print "hmm: ",repr(tst2)
        for b in range(0, len(tst2)):
            group = {}

            poster =  self.client.parseDOM(tst2[b], "div",attrs={"class": "poster"})
            print "Poster: ",repr(poster)
            text=self.client.parseDOM(poster,'div',attrs={"class": "texto"})
            text=self.client.parseDOM(poster,'div')
            print "Testo: ",repr(text)
            image=self.client.parseDOM(poster,'img',ret='src')
            quality=self.client.parseDOM(poster,'span',attrs={"class": "quality"})

            data=self.client.parseDOM(tst2[b], "div",attrs={"class": "data"})
            href=self.client.parseDOM(data,'a',ret='href')
            title=self.client.parseDOM(data,'a')
            year=self.client.parseDOM(data,'span')
            #datafeat = self.client.parseDOM(tst2[b],"div",attrs={"class": "data dfeatur"})
            #print "Datafeat: ",repr(datafeat)
            #title=self.client.parseDOM(datafeat,'a')
            #href=self.client.parseDOM(datafeat,'a',ret='href')
            #year=self.client.parseDOM(datafeat,'span')

            print "Title: ",title, " img: ",image, " href: ",href, " year: ",year

            try:
                meta = {'title': title[0], 'poster': image[0], 'year': year[0],'plot': text[0], 'orginaltitle':'title'}
                params = {'service': self.host, 'name': 'playselectedmovie', 'category': '','isplayable': 'true','url': href[0]}
                params.update(meta)
                self.add2(params)
            except Exception as e:
                self.control.log('cdaxf-1 ITEM ADD ERROR %s' % e)
                pass
        #r = self.client.parseDOM(result,'div', {"class": "col-xs-6 col-sm-3 col-lg-3"})
        #r = [(self.client.parseDOM(i, 'a', ret='href'),self.client.parseDOM(i, 'img', ret='src'),
        #      self.client.parseDOM(i, 'a', ret='data-content'),self.client.parseDOM(i, 'div', attrs={'class': 'year'}),
        #      self.client.parseDOM(i, 'div', attrs={'class': 'title'})) for i in r]

        #for i in r:
        #    self.control.log('%s' % str(i))
        #    try:
        #        tite = i[4][0].split('/')[1]
        #        titp = i[4][0].split('/')[0]
        #    except:
        #        tite = i[4][0]
        #        titp = i[4][0]
        #    try:
        #        meta = {'title': titp, 'poster': i[1][0], 'year': i[3][0],'plot': i[2][0], 'orginaltitle':tite}
        #        params = {'service': self.host, 'name': 'playselectedmovie', 'category': '','isplayable': 'true','url': i[0][0]}
        #        params.update(meta)
        #        self.add2(params)
        #    except Exception as e:
        #        self.control.log('cdaxf-1 ITEM ADD ERROR %s' % e)
        #        pass

        self.add(self.host, 'categories-menu', u'Następna strona('+str(page+1)+')',u'Następna strona('+str(page+1)+')', 'None', mynext, True, False)
        self.dirend(int(sys.argv[1]))

    def getMovieLinkFromXML(self, url):
        link = self.client.request(url)
        print "Filmy: ", repr(link)

        basefilm=self.client.parseDOM(link,'div',attrs={"class": "play-box-iframe fixidtab"})
        print "Basefilm: ",repr(basefilm)
        iframe=self.client.parseDOM(basefilm,'iframe',ret='src')
        print "iframe: ",repr(iframe)
        ctable=self.client.parseDOM(link,'div',attrs={"class": "links_table"})
        print "ctable: ", repr(ctable)
        subtable=self.client.parseDOM(link,'tbody')
        print "subtable: ", repr(subtable)
        links=self.client.parseDOM(ctable,'a',ret='href')
        images=self.client.parseDOM(ctable,'img',ret='src')
        text=self.client.parseDOM(ctable,'a')
        trs=self.client.parseDOM(subtable,'tr',ret='id')
        print "images: ", repr(trs)

        #r = self.client.parseDOM(link, 'tr')

        #r = [(self.client.parseDOM(i, 'a', ret='href'),
        #      self.client.parseDOM(i, 'img', ret='alt'),
        #      self.client.parseDOM(i, 'td')
        #      ) for i in r]

        #r = [(i[0][0], i[1][0], i[2][0], i[2][1]) for i in r if len(i[0]) > 0]

        #for i in r:
        #    self.control.log('%s' % str(i))

        tab = []
        tab2 = []
        if len(iframe)>-1:
            tab.append('Default Player')
            tab2.append(iframe[0])
        #for i in r:
        for i in range(0, len(links)):
            self.control.log("Link ALL %s" % str(i))
            #tab.append(i[1] + ' - ' + i[2]+ ' - ' + i[3])
            tds=self.client.parseDOM(subtable,'tr',attrs={"id": trs[i]})
            detale=self.client.parseDOM(tds,'td')
            print "Append image: ", images[i]
            gethost=images[i].split("=")
            tab.append(gethost[1] + ' (Jakosc: ' + detale[1] + ' - ' + detale[2] + ')')
            tab2.append(links[i])
        d = xbmcgui.Dialog()
        video_menu = d.select("Wybór strony video", tab)
        self.control.log('Altube wybrales [%s]' % video_menu)

        if video_menu != -1:
            linkVideo = tab2[video_menu]
            if 'cda-x.pl/links' in linkVideo:
                link = self.request(linkVideo)
                print "linker: ",repr(link)
                #match = re.search('<a href="(.*?)" class="btn btn-primary">Link do strony z video</a>', link)
                match = re.search('<meta name="og:url"',link)
                if match:
                    linkVid = self.client.parseDOM(link,'meta',attrs={"name": "og:url"},ret='content')
                    linkVideo=linkVid[0]

                    print "taki link: ",linkVideo
                    #linkVideo = match.group(1).split('http')[-1]
                    #linkVideo = 'http' + linkVideo
                    self.control.log('GRR  [%s]' % str(linkVideo))
            self.control.log('2 All pageparser   YXYXYYX   PLAYYYYYYERRRRRRRRRRRR [%s]' % linkVideo)
            #linkVideo = self.up.getVideoLink(tab2[video_menu], url)
            print "what resolve: ", linkVideo
            return self.urlresolve(linkVideo)
        else:
            return None


    def sub_handleService(self, params):
        name = params["name"]
        category = params["category"]

        url = params["url"]

        if name == 'main-menu' and category == 'Polecane':
            self.control.log('Jest Polecane: ')
            self.listsItems(lastUrl)
#        elif name == 'main-menu' and category == 'Kategorie':
#            self.control.log('Jest Kategorie: ')
#            self.listsCategoriesMenu()
#        elif name == 'main-menu' and category == 'Rok':
#            self.control.log('Jest Rok: ')
#            self.listsYearMenu()
        elif name == 'main-menu' and category == 'Alfabetycznie':
            self.control.log('Jest Alfabetycznie: ')
            self.listsAlphabetMenu()
        elif name == 'categories-menu':
            self.control.log('Jest categories-menu: ')
            self.listsItems2(url)





