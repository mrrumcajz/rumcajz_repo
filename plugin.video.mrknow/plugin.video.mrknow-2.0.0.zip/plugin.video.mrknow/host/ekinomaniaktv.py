# -*- coding: utf-8 -*-

'''
    plugin.video.mrknow XBMC Addon
    Copyright (C) 2017 mrknow

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
'''
import sys, urlparse, os
import htmlentitydefs
import re
from __generic_host__ import GenericHost
import HTMLParser
import xbmcgui
import urllib
import requests
from resources.lib.libraries.cfscrape import CloudflareScraper as cfscrape
from __generic_host__ import GenericHost
from search import Search


mainUrl = 'http://ekino-tv.pl/'
filmyUrl = 'http://ekino-tv.pl/movie/cat/'
dladzieciUrl = 'http://ekino-tv.pl/movie/cat/kategoria[2,3,5,6]+'
#polskieUrl = 'http://filmdom.pl/polskie/filmy-online/'
#polecaneUrl = 'http://filmdom.pl/polecane/najlepsze-filmy/'
#dladzieciUrl = 'http://filmdom.pl/gatunki/animacja/'
#catUrl = 'https://cda-x.pl/filmy-online/category:%s/?page=1'
#lastUrl = 'https://cda-x.pl/filmy/'
#szukajUrl = 'http://alltube.tv/szukaj'

class ekinotv(GenericHost):

    scriptname = 'ekinotv'
    host = 'ekinotv'
    MENU_TAB = [
        {'id': 1, 'title': 'Gorace Filmy', 'mod': 'Hot'},
        {'id': 10, 'title': 'Najnowsze Filmy', 'mod': 'Najnowsze'},
        {'id': 10, 'title': 'Najpopularniejsze Filmy', 'mod': 'Najpopularniejsze'},
        {'id': 15, 'title': 'Kategorie', 'mod': 'Kategorie'},
        {'id': 16, 'title': 'Rok', 'mod': 'Rok'},
        {'id': 17, 'title': 'Dla Dzieci', 'mod': 'Dladzieci'},
        {'id': 18, 'title': 'Szukaj', 'mod': 'Szukaj'},
    ]

    #search = Search(url='%(quoted)s', service='alltubefilmy', listItemsFun=self.listsItemsOther)



    def listsCategoriesMenu(self):
        genreSource = self.client.request(filmyUrl)

        genreBlock=self.client.parseDOM(genreSource,'ul',attrs={"class": "movieCategories"})

        genres=[(self.client.parseDOM(genreBlock,'a'),self.client.parseDOM(genreBlock,'a',ret='href'))]

        grp={}
        #for i in range(len(genres)):
        print "genres: " + repr(genres[0])
        for i in range(len(genres[0][0])):
            grp['genre']=genres[0][0][i]
            grp['href']=genres[0][1][i]


            print "href:: " + repr(grp['href'])
            print "genre: " + repr(grp['genre'])

            myurl = mainUrl + grp['href']
            self.add(self.host, 'categories-menu', grp['genre'].encode('utf-8'),grp['genre'].encode('utf-8'),  'None', myurl, True, False)

        #print "gen: " + repr(genre)
        #r = self.client.parseDOM(result, 'nav', {"class": "genres"})
        #href=self.client.parseDOM(r,'a',ret='href')
        #genre=self.client.parseDOM(r,'a')
        #r = [(self.client.parseDOM(r, 'li'), self.client.parseDOM(r, 'li', ret='data-id'))]
        #r = [(self.client.parseDOM(r[0][0][i], 'a')[0],r[0][1][i]) for i,j in enumerate(r[0][0])]
        #http://filmdom.pl/films/?search_active=1&yearOd=1950&yearDo=2018&gatunkis%5B%5D=Western
#        for i in range(0, len(genre)):
#            self.control.log('%s' % str(i))
            #myurl = catUrl  % i[1]

#            print "genre: " + genre[i].encode('utf-8')
#            myurl = filmyUrl + '/?search_active=1&yearOd=1950&yearDo=2018&gatunkis%5B%5D='+genre[i].encode('utf-8')
#            self.add(self.host, 'categories-menu', genre[i],genre[i],  'None', myurl, True, False)

        #xbmcplugin.endOfDirectory(int(sys.argv[1]))
        self.control.directory(int(sys.argv[1]))

    def listsAlphabetMenu(self):
        result = self.client.request(filmUrl)

        print "alfabet: ", repr(result)
        r = self.client.parseDOM(result, 'div', {"class": "letter_home"})
        alfabet=self.client.parseDOM(r,'a')
        #href=self.client.parseDOM(r,'a',ret='href')
        #years=self.client.parseDOM(r,'a')
        #r = [(self.client.parseDOM(r, 'li'), self.client.parseDOM(r, 'li', ret='data-id'))]
        #r = [(self.client.parseDOM(r[0][0][i], 'a')[0],r[0][1][i]) for i,j in enumerate(r[0][0])]
        for i in range(0, len(alfabet)):
            self.control.log('%s' % str(i))
        #    #myurl = catUrl  % i[1]
            myurl = filUrl
            self.add(self.host, 'categories-menu', alfabet[i],alfabet[i],  'None', myurl, True, False)
        #xbmcplugin.endOfDirectory(int(sys.argv[1]))
        self.control.directory(int(sys.argv[1]))

    def listsYearMenu(self):
        result = self.client.request(filmyUrl)
        yearBlock = self.client.parseDOM(result, 'ul', {"class": "filtyear"})

        years=self.client.parseDOM(yearBlock,'li',ret='data-id')
                #http://ekino-tv.pl/movie/cat/rok[2018]+

        tab = []
        tab2 = []


        for i in range(0,len(years)):
            tab.append(years[i])
            tab2.append(filmyUrl+'rok[%s]' % years[i])


        #http://filmdom.pl/films/?search_active=1&yearOd=2018&yearDo=2018
        #for i in range(int(yearOd[0]), int(yearDo[0])+1):
        #    print "appending: " + repr(i)
        #    v=int(yearDo[0])-i
        #    yr=int(yearOd[0])+v
        #    print "What we append: ",repr(yr)
        #    tab.append(str(yr))
        #    tab2.append(filmyUrl+'?search_active=1&yearOd='+str(yr)+'&yearDo='+str(yr))
        d = xbmcgui.Dialog()
        video_menu = d.select("Wybierz Rok", tab)
        self.control.log('filmdom wybrales [%s]' % video_menu)

        if video_menu != -1:
            return tab2[video_menu]
        else:
            return None
        #    self.control.log('%s' % str(i))
            #myurl = catUrl  % i[1]
        #    myurl = href[i]
        #    self.add(self.host, 'categories-menu', years[i],years[i],  'None', myurl, True, False)
        #xbmcplugin.endOfDirectory(int(sys.argv[1]))
        #self.control.directory(int(sys.argv[1]))


    def listsSearchResults(self, key):
        self.control.log(key)
        post_data = {'search': key}
        result = self.s.post(szukajUrl, data=post_data).text
        #self.control.log('ALA %s' % result.encode('utf-8'))
        try:
            result = re.findall('<h2 class="headline">Filmy</h2>(.*)<h2 class="headline">Seriale</h2>', result, re.DOTALL)[0]
            r = self.client.parseDOM(result, 'div', attrs={'class':'item-block clearfix'})
            r = [(self.client.parseDOM(i, 'a', ret='href'),
                  self.client.parseDOM(i, 'img', ret='src'),
                  self.client.parseDOM(i, 'h3'),
                  self.client.parseDOM(i, 'p')) for i in r]
            for i in r:
                self.control.log('ALA %s' % str(i))
                 # self.control.log('%s' % str(i) )
                try:
                    # self.control.log('AAA %s' % str(i))
                    meta = {'title': i[2][0], 'poster': i[1][0], 'year': '','plot': i[3][0]}
                    meta['originaltitle'] = i[2][0].encode('utf-8')
                    params = {'service': self.host, 'name': 'playselectedmovie', 'category': '', 'isplayable': 'true',
                              'url': i[0][0]}
                    params.update(meta)
                    self.add2(params)
                except Exception as e:
                    self.control.log('EEEEEEEEERRRTOO %s' % e)
                    pass
        except:
            pass
        self.dirend(int(sys.argv[1]))

    def mainListItems(self, url, section):


    #<span style="background-color: #cc8226;" class="page-number page-numbers current">1</span>
#        try:
#            mypagenumber = re.findall('=(\d+)',url)[0]
#            page = int(mypagenumber)
#        except:
#            page = 1
#        self.control.log('[]1 %s' % url)
#        self.control.log('[]1 %s' % page)
       # mynext = url.replace('='+str(page), '='+str(page+1))
       # self.control.log('[]2 %s' % mynext)

        '''
 <div class="mostPopular">
<div class="top">
<h4>Gorące Filmy!</h4>
<ul class="list">
<li class="anihilacja-hd-annihilation-22251-211">
<div class="scope_left"><a href="/movie/show/anihilacja-hd-annihilation-2018-lektor/22251">
<img src="//ekino-tv.pl/static/thumb/2uazbrnkkmte.jpg" style="width:68px;height:90px;" alt="Anihilacja - HD / Annihilation"></a>
<div class="s-star_bg"><div class="num">7.0</div></div>
</div>
<div class="scope_right">
<div class="title">
<a href="/movie/show/anihilacja-hd-annihilation-2018-lektor/22251">Anihilacja - HD&nbsp;</a><br>
<span class="blue">
<a class="blue" href="/movie/show/anihilacja-hd-annihilation-2018-lektor/22251">Annihilation</a></span>
</div>
<div class="info-categories">
<p class="cates">2018 | <a href="/movie/cat/kategoria[1]">Akcja</a>,<a href="/movie/cat/kategoria[35]">HD</a>,
<a href="/movie/cat/kategoria[28]">Sci-fi</a>,<a href="/movie/cat/kategoria[31]">Thriller</a></p>
<i title="Lektor" class="glyphicon glyphicon-bullhorn"></i> </div>
<div class="movieDesc">
Lena (Natalie Portman), biolożka i była żołnierka, pr&oacute;buje rozwikłać tajemnicę zaginięcia swojego męża w Strefie X &mdash;
nieprzyjaznym i tajemniczym miejscu rozciągającym się... </div>
</li>
        '''
        result = self.request(url, utf=False)
        print "~~~URL: ", repr(url)
        #print "~~~ekinotv->Strona: ",repr(result)

        #<ul class="pagination">
#        pagination=self.client.parseDOM(result,'ul',attrs={"class": "pagination"})
#        print "pagination: " + repr(pagination)
#        currentpage=self.client.parseDOM(pagination,'span',attrs={"class": "page-number page-numbers current"})
        mainpage = self.client.parseDOM(result,'div',attrs={"class": "mainWrap"})
        movpage=self.client.parseDOM(result,'ul',attrs={"class": "list"})
        #movpage=self.client.parseDOM(result,'div',attrs={"class": "mostPopular"})



        #movieslist=[(self.client.parseDOM(movpage,'li'),self.client.parseDOM(movpage,'a',ret='href'),self.clientparseDOM(movpage,'img',ret='src'),
        #              self.client.parseDOM(movpage,''))

        print "sub: "+ str(len(movpage)) + repr(movpage)

        print "sub2: " + repr(movpage[0])

        movielist=self.client.parseDOM(movpage[section],'li')

        grp={}
        for i in range(len(movielist)):
            grp['href']=mainUrl+self.client.parseDOM(movielist[i],'a',ret='href')[0]
            grp['image']='http:'+self.client.parseDOM(movielist[i],'img',ret='src')[0]
            grp['title']=self.client.parseDOM(self.client.parseDOM(movielist[i],'div',attrs={"class": "title"}),'a')[0].encode('raw_unicode_escape').decode('utf-8')
            grp['plot']=self.client.parseDOM(movielist[i],'div',attrs={"class": "movieDesc"})[0].encode('raw_unicode_escape').decode('utf-8')


            grp['year']=self.client.parseDOM(movielist[i],'p',attrs={"class": "cates"})[0].split('|')[0].replace(" ","")

            grp['title']=re.sub('&([^;]+);', lambda m: unichr(htmlentitydefs.name2codepoint[m.group(1)]), grp['title'])
            grp['plot']=re.sub('&([^;]+);', lambda m: unichr(htmlentitydefs.name2codepoint[m.group(1)]), grp['plot'])

            #test=grp['plot'][0]
            #print "Text0: " + test
            #print "Text1: " + test.decode('utf-8')
           # print "Text2: " + test.encode('utf-8')
            print "href: " + repr(grp['href'])
            print "title: " + repr(grp['title'])
            print "plot: " + repr(grp['plot'])
            print "year: " + repr(grp['year'])
#        allfilms = self.client.parseDOM(result,'div', attrs={"class": "films"})
#        subfilms = self.client.parseDOM(result,'div', attrs={"class": "film_content"})
#        grp = {}
#        for i in range(0, len(subfilms)):
#            grp['image'] = self.client.parseDOM(subfilms[i],'img', ret='src')
#            grp['title'] = self.client.parseDOM(subfilms[i],'img', ret='title')
#            grp['href'] = self.client.parseDOM(subfilms[i],'a', ret='href')[0]
#            grp['year'] = self.client.parseDOM(subfilms[i],'span',attrs={"class": "accent_btn film_year"})

#            print "Href: ", repr(grp['href'])

            try:
                meta = {'title': grp['title'], 'poster': grp['image'], 'year': grp['year'],'plot': grp['plot'], 'orginaltitle':grp['title']}
                params = {'service': self.host, 'name': 'playselectedmovie', 'category': '','isplayable': 'true','url': grp['href']}
                params.update(meta)
                self.add2(params)
            except Exception as e:
                self.control.log('filmdom-1 ITEM ADD ERROR %s' % e)
                pass


    #    if len(pages)>-1:
    #        print "pages: ", repr(pages)
    #        print "VAL: " +  currentpage[0]
            #http://filmdom.pl/films/page/2/?search_active=1&yearOd=1950&yearDo=2018&gatunkis%5B0%5D=Akcja&gatunkis%5B1%5D=Ba%C5%9B%C5%84
    #        mynext=pages[0+int(currentpage[0])]
    #        self.add(self.host, 'categories-menu', u'Następna strona ('+str(int(currentpage[0])+1)+')',u'Następna strona ('+str(int(currentpage[0])+1)+')',  'None', mynext, True, False)
        #print "hmm1: ",repr(tst)
        #tst2 = self.client.parseDOM(tst,'article', attrs={"class": "item movies"})
        #print "hmm: ",repr(tst2)
        #for b in range(0, len(tst2)):
        #    group = {}
        #    poster =  self.client.parseDOM(tst2[b], "div",attrs={"class": "poster"})
        #    print "Poster: ",repr(poster)
        #    image=self.client.parseDOM(poster,'img',ret='src')
        #    datafeat = self.client.parseDOM(tst2[b],"div",attrs={"class": "data dfeatur"})
        #    print "Datafeat: ",repr(datafeat)
        #    title=self.client.parseDOM(datafeat,'a')
        #    href=self.client.parseDOM(datafeat,'a',ret='href')
        #    year=self.client.parseDOM(datafeat,'span')

        #    print "Title: ",title, " img: ",image, " href: ",href

        #    try:
        #        meta = {'title': title[0], 'poster': image[0], 'year': year[0],'plot': 'plot', 'orginaltitle':'title'}
        #        params = {'service': self.host, 'name': 'playselectedmovie', 'category': '','isplayable': 'true','url': href[0]}
        #        params.update(meta)
        #        self.add2(params)
        #    except Exception as e:
        #        self.control.log('cdaxf-1 ITEM ADD ERROR %s' % e)
        #        pass
        #r = self.client.parseDOM(result,'div', {"class": "col-xs-6 col-sm-3 col-lg-3"})
        #r = [(self.client.parseDOM(i, 'a', ret='href'),self.client.parseDOM(i, 'img', ret='src'),
        #      self.client.parseDOM(i, 'a', ret='data-content'),self.client.parseDOM(i, 'div', attrs={'class': 'year'}),
        #      self.client.parseDOM(i, 'div', attrs={'class': 'title'})) for i in r]

        #for i in r:
        #    self.control.log('%s' % str(i))
        #    try:
        #        tite = i[4][0].split('/')[1]
        #        titp = i[4][0].split('/')[0]
        #    except:
        #        tite = i[4][0]
        #        titp = i[4][0]
        #    try:
        #        meta = {'title': titp, 'poster': i[1][0], 'year': i[3][0],'plot': i[2][0], 'orginaltitle':tite}
        #        params = {'service': self.host, 'name': 'playselectedmovie', 'category': '','isplayable': 'true','url': i[0][0]}
        #        params.update(meta)
        #        self.add2(params)
        #    except Exception as e:
        #        self.control.log('cdaxf-1 ITEM ADD ERROR %s' % e)
        #        pass

        #self.add(self.host, 'categories-menu', u'Następna strona',u'Następna strona',  'None', mynext, True, False)
        self.dirend(int(sys.argv[1]))


    def listsItems(self, url):


    #<span style="background-color: #cc8226;" class="page-number page-numbers current">1</span>
#        try:
#            mypagenumber = re.findall('=(\d+)',url)[0]
#            page = int(mypagenumber)
#        except:
#            page = 1
#        self.control.log('[]1 %s' % url)
#        self.control.log('[]1 %s' % page)
       # mynext = url.replace('='+str(page), '='+str(page+1))
       # self.control.log('[]2 %s' % mynext)

        '''
        <div class="movies-list-item" id="time-rush-2016-napisy">
<div class="cover-list"><a href="/movie/show/time-rush-2016-napisy/22303"><img src="/static/thumb/kx8t6z3mhhdy.jpg" alt="Time Rush / " /></a></div>
<div class="opis-list">
<div class="title">
<a href="/movie/show/time-rush-2016-napisy/22303">Time Rush&nbsp;</a><br>
<span class="blue" style="color: rgb(51, 142, 195);">
<a class="blue" href="/movie/show/time-rush-2016-napisy/22303" style="color: rgb(51, 142, 195);"></a>
</span>
</div>
<div class="info-categories" style="color:#464646;">
<p class="cates">2016 | <a href="/movie/cat/kategoria[1]">Akcja</a></p>
<i title="Napisy" class="glyphicon glyphicon-align-left"></i>
</div>
<div class="movieDesc">
Alan zostaje uwięziony w pętli czasu. Ucieka przez tętniące życiem ulice Bangkoku przed tajemniczymi zab&oacute;jcami, a każda nieudana pr&oacute;ba powoduje rozpoczęcie gry od nowa. </div>
</div>
<div class="info-list">
<div class="sum-vote"><div style="padding-top:7px;color: rgb(138, 138, 138);font-weight: bold;">3.3</div></div>
<div class="h-line"></div>
<font style="font-size:12px;color: rgb(93, 93, 93);font-weight: bold;">Ocen</font><br />
<font style="font-size:13px;color:rgb(138, 138, 138);font-weight: bold;">3</font><br />
</div>
</div>

        '''
        #link = self.client.request(url)
        result = self.request(url, utf=False)
        print "~~~URL: ", repr(url)
        print "~~~Ekino-tv->Strona: ",repr(result)
        movieSource=self.client.parseDOM(result,'div',attrs={"class": "col-md-8 movie-wrap"})
        moviesBlock=self.client.parseDOM(movieSource,'div', attrs={"class": "movies-list-item"})

        '''

           grp['image']='http:'+self.client.parseDOM(movielist[i],'img',ret='src')[0]
            grp['title']=self.client.parseDOM(self.client.parseDOM(movielist[i],'div',attrs={"class": "title"}),'a')[0].encode('raw_unicode_escape').decode('utf-8')
            grp['plot']=self.client.parseDOM(movielist[i],'div',attrs={"class": "movieDesc"})[0].encode('raw_unicode_escape').decode('utf-8')


            grp['year']=self.client.parseDOM(movielist[i],'p',attrs={"class": "cates"})[0].split('|')[0].replace(" ","")

            grp['title']=re.sub('&([^;]+);', lambda m: unichr(htmlentitydefs.name2codepoint[m.group(1)]), grp['title'])
            grp['plot']=re.sub('&([^;]+);', lambda m: unichr(htmlentitydefs.name2codepoint[m.group(1)]), grp['plot'])

        '''
        grp={}
        for i in range(len(moviesBlock)):

              grp['href']=mainUrl[0:-1]+self.client.parseDOM(moviesBlock[i],'a',ret='href')[0]

              if re.search("/movie/",grp['href']):
                  grp['title']=self.client.parseDOM(self.client.parseDOM(moviesBlock[i],'div',attrs={"class": "title"}),'a')[0].encode('raw_unicode_escape').decode('utf-8')
                  grp['image']=mainUrl[0:-1]+self.client.parseDOM(moviesBlock[i],'img',ret='src')[0]
                  grp['plot']=self.client.parseDOM(moviesBlock[i],'div',attrs={"class": "movieDesc"})[0].encode('raw_unicode_escape').decode('utf-8')

                  print "Just cates: " + repr(self.client.parseDOM(moviesBlock[i],'p',attrs={"class": "cates"}))
                  grp['year']=self.client.parseDOM(moviesBlock[i],'p',attrs={"class": "cates"})[0].split('|')[0].replace(" ","")

                  grp['title']=re.sub('&([^;]+);', lambda m: unichr(htmlentitydefs.name2codepoint[m.group(1)]), grp['title'])
                  grp['plot']=re.sub('&([^;]+);', lambda m: unichr(htmlentitydefs.name2codepoint[m.group(1)]), grp['plot'])

                  try:
                    meta = {'title': grp['title'], 'poster': grp['image'], 'year': grp['year'],'plot': grp['plot'], 'orginaltitle':grp['title']}
                    params = {'service': self.host, 'name': 'playselectedmovie', 'category': '','isplayable': 'true','url': grp['href']}
                    params.update(meta)
                    self.add2(params)
                  except Exception as e:
                    self.control.log('filmdom-1 ITEM ADD ERROR %s' % e)
                    pass

        pagerSource=self.client.parseDOM(result,'div',attrs={"id": "pager"})
        if pagerSource:
            currentPage=self.client.parseDOM(pagerSource,'span')
            nextUrls=self.client.parseDOM(pagerSource,'a',ret='href')
            lastUrl=self.client.parseDOM(pagerSource,'i',attrs={"class": "glyphicon glyphicon-arrow-right"},ret='class')


            print "pagersource: " + repr(pagerSource)
            print "currenpage: " + repr(currentPage)
            print "nextUrls: " + repr(nextUrls)
            print "lastUrl: " + repr(lastUrl)

            if int(currentPage[0])==1:
                nextPage=nextUrls[0]
                self.add(self.host, 'categories-menu', u'Następna strona ('+str(int(currentPage[0])+1)+')',u'Następna strona ('+str(int(currentPage[0])+1)+')',  'None', nextPage, True, False)
            else:
                #if re.match("glyphicon glyphicon-arrow-right",lastUrl):
                if lastUrl:
                    print "It's a match: " + repr(lastUrl)
                    nextPage=nextUrls[int(currentPage[0])]
                    self.add(self.host, 'categories-menu', u'Następna strona ('+str(int(currentPage[0])+1)+')',u'Następna strona ('+str(int(currentPage[0])+1)+')',  'None', nextPage, True, False)



        #pagerSource=self.client.parseDOM(result,'div',attrs={"id": "pager"})
#        if len(pages)>-1:
#            print "pages: ", repr(pages)
#            print "VAL: " +  currentpage[0]
#            #http://filmdom.pl/films/page/2/?search_active=1&yearOd=1950&yearDo=2018&gatunkis%5B0%5D=Akcja&gatunkis%5B1%5D=Ba%C5%9B%C5%84
#            mynext=pages[0+int(currentpage[0])]
#            self.add(self.host, 'categories-menu', u'Następna strona ('+str(int(currentpage[0])+1)+')',u'Następna strona ('+str(int(currentpage[0])+1)+')',  'None', mynext, True, False)
        #print "hmm1: ",repr(tst)
        #tst2 = self.client.parseDOM(tst,'article', attrs={"class": "item movies"})
        #print "hmm: ",repr(tst2)
        #for b in range(0, len(tst2)):
        #    group = {}
        #    poster =  self.client.parseDOM(tst2[b], "div",attrs={"class": "poster"})
        #    print "Poster: ",repr(poster)
        #    image=self.client.parseDOM(poster,'img',ret='src')
        #    datafeat = self.client.parseDOM(tst2[b],"div",attrs={"class": "data dfeatur"})
        #    print "Datafeat: ",repr(datafeat)
        #    title=self.client.parseDOM(datafeat,'a')
        #    href=self.client.parseDOM(datafeat,'a',ret='href')
        #    year=self.client.parseDOM(datafeat,'span')

        #    print "Title: ",title, " img: ",image, " href: ",href

        #    try:
        #        meta = {'title': title[0], 'poster': image[0], 'year': year[0],'plot': 'plot', 'orginaltitle':'title'}
        #        params = {'service': self.host, 'name': 'playselectedmovie', 'category': '','isplayable': 'true','url': href[0]}
        #        params.update(meta)
        #        self.add2(params)
        #    except Exception as e:
        #        self.control.log('cdaxf-1 ITEM ADD ERROR %s' % e)
        #        pass
        #r = self.client.parseDOM(result,'div', {"class": "col-xs-6 col-sm-3 col-lg-3"})
        #r = [(self.client.parseDOM(i, 'a', ret='href'),self.client.parseDOM(i, 'img', ret='src'),
        #      self.client.parseDOM(i, 'a', ret='data-content'),self.client.parseDOM(i, 'div', attrs={'class': 'year'}),
        #      self.client.parseDOM(i, 'div', attrs={'class': 'title'})) for i in r]

        #for i in r:
        #    self.control.log('%s' % str(i))
        #    try:
        #        tite = i[4][0].split('/')[1]
        #        titp = i[4][0].split('/')[0]
        #    except:
        #        tite = i[4][0]
        #        titp = i[4][0]
        #    try:
        #        meta = {'title': titp, 'poster': i[1][0], 'year': i[3][0],'plot': i[2][0], 'orginaltitle':tite}
        #        params = {'service': self.host, 'name': 'playselectedmovie', 'category': '','isplayable': 'true','url': i[0][0]}
        #        params.update(meta)
        #        self.add2(params)
        #    except Exception as e:
        #        self.control.log('cdaxf-1 ITEM ADD ERROR %s' % e)
        #        pass

        #self.add(self.host, 'categories-menu', u'Następna strona',u'Następna strona',  'None', mynext, True, False)
        self.dirend(int(sys.argv[1]))

    def listsItems2(self, url):
        result = self.request(url, utf=False)
        try:
            pagestrona=self.client.parseDOM(result,'div',attrs={"class": "pagination"})
            mypage=self.client.parseDOM(result,'span',attrs={"class": "current"})
            #mypagenumber = re.findall('=(\d+)',url)[0]
            page = int(mypage[0])
        except:
            page = 1
        self.control.log('[]1 %s' % url)
        self.control.log('[]1 %s' % page)

        if re.search('page',url):
            mynext=url.replace('/'+str(page), '/'+str(page+1))
        else:
            mynext = url + "page/"+str(page+1)+"/"
            print "nexturl: ",repr(mynext)
       # self.control.log('[]2 %s' % mynext)

        #link = self.client.request(url)
        #result = self.request(url, utf=False)
        print "Strona: ",repr(result)
        tst = self.client.parseDOM(result,'div', attrs={"class": "items"})
        print "hmm1: ",repr(tst)
        tst2 = self.client.parseDOM(tst,'article', attrs={"class": "item movies"})
        print "hmm: ",repr(tst2)
        for b in range(0, len(tst2)):
            group = {}

            poster =  self.client.parseDOM(tst2[b], "div",attrs={"class": "poster"})
            print "Poster: ",repr(poster)
            text=self.client.parseDOM(poster,'div',attrs={"class": "texto"})
            text=self.client.parseDOM(poster,'div')
            print "Testo: ",repr(text)
            image=self.client.parseDOM(poster,'img',ret='src')
            quality=self.client.parseDOM(poster,'span',attrs={"class": "quality"})

            data=self.client.parseDOM(tst2[b], "div",attrs={"class": "data"})
            href=self.client.parseDOM(data,'a',ret='href')
            title=self.client.parseDOM(data,'a')
            year=self.client.parseDOM(data,'span')
            #datafeat = self.client.parseDOM(tst2[b],"div",attrs={"class": "data dfeatur"})
            #print "Datafeat: ",repr(datafeat)
            #title=self.client.parseDOM(datafeat,'a')
            #href=self.client.parseDOM(datafeat,'a',ret='href')
            #year=self.client.parseDOM(datafeat,'span')

            print "Title: ",title, " img: ",image, " href: ",href, " year: ",year

            try:
                meta = {'title': title[0], 'poster': image[0], 'year': year[0],'plot': text[0], 'orginaltitle':'title'}
                params = {'service': self.host, 'name': 'playselectedmovie', 'category': '','isplayable': 'true','url': href[0]}
                params.update(meta)
                self.add2(params)
            except Exception as e:
                self.control.log('cdaxf-1 ITEM ADD ERROR %s' % e)
                pass
        #r = self.client.parseDOM(result,'div', {"class": "col-xs-6 col-sm-3 col-lg-3"})
        #r = [(self.client.parseDOM(i, 'a', ret='href'),self.client.parseDOM(i, 'img', ret='src'),
        #      self.client.parseDOM(i, 'a', ret='data-content'),self.client.parseDOM(i, 'div', attrs={'class': 'year'}),
        #      self.client.parseDOM(i, 'div', attrs={'class': 'title'})) for i in r]

        #for i in r:
        #    self.control.log('%s' % str(i))
        #    try:
        #        tite = i[4][0].split('/')[1]
        #        titp = i[4][0].split('/')[0]
        #    except:
        #        tite = i[4][0]
        #        titp = i[4][0]
        #    try:
        #        meta = {'title': titp, 'poster': i[1][0], 'year': i[3][0],'plot': i[2][0], 'orginaltitle':tite}
        #        params = {'service': self.host, 'name': 'playselectedmovie', 'category': '','isplayable': 'true','url': i[0][0]}
        #        params.update(meta)
        #        self.add2(params)
        #    except Exception as e:
        #        self.control.log('cdaxf-1 ITEM ADD ERROR %s' % e)
        #        pass

        self.add(self.host, 'categories-menu', u'Następna strona('+str(page+1)+')',u'Następna strona('+str(page+1)+')', 'None', mynext, True, False)
        self.dirend(int(sys.argv[1]))



    def getMovieLinkFromXML(self, url):
        print "What url: ", repr(url)

        moviepage = self.client.request(url)
        print "Filmy: ", repr(moviepage)

#        basefilm=self.client.parseDOM(link,'div',attrs={"class": "play-box-iframe fixidtab"})
#        print "Basefilm: ",repr(basefilm)
#        iframe=self.client.parseDOM(basefilm,'iframe',ret='src')
#        print "iframe: ",repr(iframe)
#        ctable=self.client.parseDOM(link,'div',attrs={"class": "links_table"})
#        print "ctable: ", repr(ctable)
#        subtable=self.client.parseDOM(link,'tbody')
#        print "subtable: ", repr(subtable)
#        links=self.client.parseDOM(ctable,'a',ret='href')
#        images=self.client.parseDOM(ctable,'img',ret='src')
#        text=self.client.parseDOM(ctable,'a')
#        trs=self.client.parseDOM(subtable,'tr',ret='id')
#        print "images: ", repr(trs)
        #<tbody id="all-links">
        #r = [(self.client.parseDOM(i, 'a', ret='href'),self.client.parseDOM(i, 'img', ret='src'),
        #      self.client.parseDOM(i, 'a', ret='data-content'),self.client.parseDOM(i, 'div', attrs={'class': 'year'}),
        #      self.client.parseDOM(i, 'div', attrs={'class': 'title'})) for i in r]

        players=self.client.parseDOM(moviepage,'div',attrs={"class": "playerContainer"})

        print "Players: " + repr(players)
        '''
         <div class="playerContainer">
<div style="min-height:40px;overflow: hidden;">
<ul class="players" role="tablist" id="myTab">
<li><a href="#4QEuZCiUsH0ZUF2YwolTxnTUTQ49bu5s8IfZI4U-fone" data-toggle="tab">fone
<i class="glyphicon glyphicon-bullhorn" title="Lektor PL"></i>
<img src="/views/img/q3.png" title="Wysoka jakość" />
</a></li>
<li><a href="#JHW-aCR6GfeN006twc17u9gqnxM50fV2ar9Y-openload" data-toggle="tab">openload
<i class="glyphicon glyphicon-bullhorn" title="Lektor PL"></i>
<img src="/views/img/q3.png" title="Wysoka jakość" />
</a></li>

<div class="tab-content">
<div role="tabpanel" class="tab-pane fade" id="4QEuZCiUsH0ZUF2YwolTxnTUTQ49bu5s8IfZI4U-fone">
<a onClick="ShowPlayer('fone','4QEuZCiUsH0ZUF2YwolTxnTUTQ49bu5s8IfZI4U')"><img style="width:640px;height:360px;cursor:pointer;" src="/views/img/kliknij_aby_obejrzec.jpg" id="freePlayerClickf_4QEuZCiUsH0ZUF2YwolTxnTUTQ49bu5s8IfZI4U" alt="Kliknij aby obejrzeć"></a>
<div id="fplayer_4QEuZCiUsH0ZUF2YwolTxnTUTQ49bu5s8IfZI4U"></div>
</div>
<div role="tabpanel" class="tab-pane fade" id="JHW-aCR6GfeN006twc17u9gqnxM50fV2ar9Y-openload">
<a onClick="ShowPlayer('openload','JHW-aCR6GfeN006twc17u9gqnxM50fV2ar9Y')"><img style="width:640px;height:360px;cursor:pointer;" src="/views/img/kliknij_aby_obejrzec.jpg" id="freePlayerClickf_JHW-aCR6GfeN006twc17u9gqnxM50fV2ar9Y" alt="Kliknij aby obejrzeć"></a>
<div id="fplayer_JHW-aCR6GfeN006twc17u9gqnxM50fV2ar9Y"></div>
</div>
<div role="tabpanel" class="tab-pane fade" id="TWYrdyFsOBKpEBcTD3EQlEEWkK7xP-ToCsfcuUS3_j0-smango">
<a onClick="ShowPlayer('smango','TWYrdyFsOBKpEBcTD3EQlEEWkK7xP-ToCsfcuUS3_j0')"><img style="width:640px;height:360px;cursor:pointer;" src="/views/img/kliknij_aby_obejrzec.jpg" id="freePlayerClickf_TWYrdyFsOBKpEBcTD3EQlEEWkK7xP-ToCsfcuUS3_j0" alt="Kliknij aby obejrzeć"></a>
<div id="fplayer_TWYrdyFsOBKpEBcTD3EQlEEWkK7xP-ToCsfcuUS3_j0"></div>
        '''

        playerid=self.client.parseDOM(players,'a',ret='onClick')

        print "Player ID: " + repr(playerid)

            #print "My New URL: " + newurl
            #playersrc = self.client.request(newurl);

        #linknames=self.client.parseDOM(moviepage,'tbody',attrs={"id": "all-links"})
        #linknames=self.client.parseDOM(linknames,'tr')
        #linknames=[(self.client.parseDOM(i,'td')) for i in linknames]


        #subset = self.client.parseDOM(moviepage,'script')

       # for i in subset:
       #     if re.search("var PublicLink",i):
       #         linkset=i

      #  linkset=linkset[19:-2]
      #  linkset=re.sub('"','',linkset)
      #  linkset=linkset.replace('\\','')
      #  movielinks=re.split(',',linkset)

        #r = self.client.parseDOM(link, 'tr')

        #r = [(self.client.parseDOM(i, 'a', ret='href'),
        #      self.client.parseDOM(i, 'img', ret='alt'),
        #      self.client.parseDOM(i, 'td')
        #      ) for i in r]

        #r = [(i[0][0], i[1][0], i[2][0], i[2][1]) for i in r if len(i[0]) > 0]

        #for i in r:
        #    self.control.log('%s' % str(i))

        tab = []
        tab2 = []

        for i in playerid:
            print "My player id: " + repr(i)
            host,src=i[11:-1].replace("'","").split(",")
            newurl=mainUrl+'watch/f/'+host+'/'+src
            #print "Myurl: " + newurl
            #scraper = cfscrape.create_scraper(sess=self.s)
            #superd = scraper.get(newurl,stream=True)
            #print "superd: " + repr(superd.content)
            playersrc=self.client.request(newurl)
            #print "playersrc: " + repr(playersrc.content)
            #head=requests.head(newurl,allow_redirects=True)
            playeruri=self.client.parseDOM(playersrc,'script')

            for b in playeruri:
                if re.match("var url",b):
                    filmurl=b[11:-2]
                                                                       #meta name="og:url"
            #filmurl=self.client.parseDOM(playersrc,'meta',attrs={"name": "og:url"},ret='content')

                    tab.append(host)
                    print "Adding Film URL: " + filmurl
                    tab2.append(filmurl)

        tab.append('testflick')
        tab2.append('https://vshare.io/v/1db4116/width-650/height-430/1')
       # for i in range(len(movielinks)):
        #    tab.append(linknames[i][3] + ' ('+linknames[i][1]+' - '+linknames[i][2]+')')
        #    tab2.append(movielinks[i])
#        if len(iframe)>-1:
#            tab.append('Default Player')
#            tab2.append(iframe[0])
        #for i in r:
        #for i in range(0, len(links)):
        #    self.control.log("Link ALL %s" % str(i))
        #    #tab.append(i[1] + ' - ' + i[2]+ ' - ' + i[3])
        #    tds=self.client.parseDOM(subtable,'tr',attrs={"id": trs[i]})
        #    detale=self.client.parseDOM(tds,'td')
        #    print "Append image: ", images[i]
        #    gethost=images[i].split("=")
        #    tab.append(gethost[1] + ' (Jakosc: ' + detale[1] + ' - ' + detale[2] + ')')
        #    tab2.append(links[i])
        d = xbmcgui.Dialog()
        video_menu = d.select("Wybór strony video", tab)
        self.control.log('filmdom wybrales [%s]' % video_menu)

        if video_menu != -1:
            linkVideo = tab2[video_menu]
            if 'cda-x.pl/links' in linkVideo:
                link = self.request(linkVideo)
                print "linker: ",repr(link)
                #match = re.search('<a href="(.*?)" class="btn btn-primary">Link do strony z video</a>', link)
                match = re.search('<meta name="og:url"',link)
                if match:
                    linkVid = self.client.parseDOM(link,'meta',attrs={"name": "og:url"},ret='content')
                    linkVideo=linkVid[0]

                    print "taki link: ",linkVideo
                    #linkVideo = match.group(1).split('http')[-1]
                    #linkVideo = 'http' + linkVideo
                    self.control.log('GRR  [%s]' % str(linkVideo))
            self.control.log('2 All pageparser   YXYXYYX   PLAYYYYYYERRRRRRRRRRRR [%s]' % linkVideo)
            #linkVideo = self.up.getVideoLink(tab2[video_menu], url)
            print "what resolve: ", linkVideo
            return self.urlresolve(linkVideo)
        else:
            return None

    def getSearch(self):
        dialog = xbmcgui.Dialog()
        d = dialog.input('Szukaj, Podaj tytuł filmu', type=xbmcgui.INPUT_ALPHANUM)
        return mainUrl+'s/search?q='+d.replace(' ','+')

    def sub_handleService(self, params):
        name = params["name"]
        category = params["category"]

        url = params["url"]

        if name == 'main-menu' and category == 'Hot':
            self.control.log('Jest Hot: ')
            self.mainListItems(mainUrl,0)
        if name == 'main-menu' and category == 'Najnowsze':
            self.control.log('Jest Najnowsze: ')
            self.mainListItems(mainUrl,1)
        if name == 'main-menu' and category == 'Najpopularniejsze':
            self.control.log('Jest Najpopularniejsze: ')
            self.mainListItems(mainUrl,2)

        if name == 'main-menu' and category == 'Dladzieci':
            self.control.log('Jest dla dziecie: ')
            self.listsItems(dladzieciUrl)
        elif name == 'main-menu' and category == 'Kategorie':
            self.control.log('Jest Kategorie: ')
            self.listsCategoriesMenu()
        elif name == 'main-menu' and category == 'Szukaj':
            searchUrl=self.getSearch()
            self.listsItems(searchUrl)
            #dialog = xbmcgui.Dialog()
            #d = dialog.input('Szukaj, Podaj tytuł filmu', type=xbmcgui.INPUT_ALPHANUM)
            #pozycje = EK.szukaj(d.replace(' ','%20'))
        elif name == 'categories-menu':
            self.control.log('Jest categories-menu: ')
            self.listsItems(url)
        elif name == 'main-menu' and category == 'Rok':
            self.control.log('Jest Rok: ')
            #self.listsYearMenu()
            data = self.listsYearMenu()
            print "DAT: " + repr(data)
            if data != None:
                self.listsItems(data)





