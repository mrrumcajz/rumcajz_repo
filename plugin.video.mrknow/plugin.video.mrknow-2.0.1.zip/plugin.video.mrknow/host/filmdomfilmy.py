# -*- coding: utf-8 -*-

'''
    plugin.video.mrknow XBMC Addon
    Copyright (C) 2017 mrknow

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
'''
import sys, urlparse, os
import re
from __generic_host__ import GenericHost
import HTMLParser
import xbmcgui
import urllib

from __generic_host__ import GenericHost
from search import Search


mainUrl = 'https://filmdom.pl/'
filmyUrl = 'http://filmdom.pl/films/'
polskieUrl = 'http://filmdom.pl/polskie/filmy-online/'
polecaneUrl = 'http://filmdom.pl/polecane/najlepsze-filmy/'
dladzieciUrl = 'http://filmdom.pl/gatunki/animacja/'
#catUrl = 'https://cda-x.pl/filmy-online/category:%s/?page=1'
#lastUrl = 'https://cda-x.pl/filmy/'
#szukajUrl = 'http://alltube.tv/szukaj'

class filmdomfilmy(GenericHost):

    scriptname = 'filmdomfilmy'
    host = 'filmdomfilmy'
    MENU_TAB = [
        {'id': 1, 'title': 'Polecane', 'mod': 'Polecane'},
        {'id': 10, 'title': 'Polskie', 'mod': 'Polskie'},
        {'id': 15, 'title': 'Kategorie', 'mod': 'Kategorie'},
        {'id': 20, 'title': 'Rok', 'mod': 'Rok'},
        {'id': 25, 'title': 'Dla Dzieci', 'mod': 'DlaDzieci'},

        #{'id': 30, 'title': 'Alfabetycznie', 'mod': 'Alfabetycznie'},
         #{'id': 4, 'title': 'Szukaj', 'mod': 'find', },
        #{'id': 5, 'title': 'Historia wyszukiwania', 'mod': 'history'},
        # {'id': 3, 'title': 'Bajki', 'mod': 'ListBajki', },
        # {'id': 3, 'title': 'Bajki', 'mod': 'ListBajki', },


    ]

    #search = Search(url='%(quoted)s', service='alltubefilmy', listItemsFun=self.listsItemsOther)

    def listsCategoriesMenu(self):
        genresult = self.client.request(filmyUrl)

        genre=self.client.parseDOM(genresult,'input',attrs={"name": "gatunkis[]"},ret="value")


        print "gen: " + repr(genre)
        #r = self.client.parseDOM(result, 'nav', {"class": "genres"})
        #href=self.client.parseDOM(r,'a',ret='href')
        #genre=self.client.parseDOM(r,'a')
        #r = [(self.client.parseDOM(r, 'li'), self.client.parseDOM(r, 'li', ret='data-id'))]
        #r = [(self.client.parseDOM(r[0][0][i], 'a')[0],r[0][1][i]) for i,j in enumerate(r[0][0])]
        #http://filmdom.pl/films/?search_active=1&yearOd=1950&yearDo=2018&gatunkis%5B%5D=Western
        for i in range(0, len(genre)):
            self.control.log('%s' % str(i))
            #myurl = catUrl  % i[1]

            print "genre: " + genre[i].encode('utf-8')
            myurl = filmyUrl + '/?search_active=1&yearOd=1950&yearDo=2018&gatunkis%5B%5D='+genre[i].encode('utf-8')
            self.add(self.host, 'categories-menu', genre[i],genre[i],  'None', myurl, True, False)

        #xbmcplugin.endOfDirectory(int(sys.argv[1]))
        self.control.directory(int(sys.argv[1]))

    def listsAlphabetMenu(self):
        result = self.client.request(filmUrl)

        print "alfabet: ", repr(result)
        r = self.client.parseDOM(result, 'div', {"class": "letter_home"})
        alfabet=self.client.parseDOM(r,'a')
        #href=self.client.parseDOM(r,'a',ret='href')
        #years=self.client.parseDOM(r,'a')
        #r = [(self.client.parseDOM(r, 'li'), self.client.parseDOM(r, 'li', ret='data-id'))]
        #r = [(self.client.parseDOM(r[0][0][i], 'a')[0],r[0][1][i]) for i,j in enumerate(r[0][0])]
        for i in range(0, len(alfabet)):
            self.control.log('%s' % str(i))
        #    #myurl = catUrl  % i[1]
            myurl = filUrl
            self.add(self.host, 'categories-menu', alfabet[i],alfabet[i],  'None', myurl, True, False)
        #xbmcplugin.endOfDirectory(int(sys.argv[1]))
        self.control.directory(int(sys.argv[1]))

    def listsYearMenu(self):
        result = self.client.request(filmyUrl)
        r = self.client.parseDOM(result, 'label', {"class": "year-fields"})
        yearOd=self.client.parseDOM(r, 'input', {"name": "yearOd"},ret='value')
        yearDo=self.client.parseDOM(r, 'input', {"name": "yearDo"},ret='value')
        #href=self.client.parseDOM(r,'a',ret='href')
        #years=self.client.parseDOM(r,'a')
        #r = [(self.client.parseDOM(r, 'li'), self.client.parseDOM(r, 'li', ret='data-id'))]
        #r = [(self.client.parseDOM(r[0][0][i], 'a')[0],r[0][1][i]) for i,j in enumerate(r[0][0])]
        print "Years: " + repr(yearOd) + "--"+repr(yearDo)
        tab = []
        tab2 = []
        #http://filmdom.pl/films/?search_active=1&yearOd=2018&yearDo=2018
        for i in range(int(yearOd[0]), int(yearDo[0])+1):
            print "appending: " + repr(i)
            v=int(yearDo[0])-i
            yr=int(yearOd[0])+v
            print "What we append: ",repr(yr)
            tab.append(str(yr))
            tab2.append(filmyUrl+'?search_active=1&yearOd='+str(yr)+'&yearDo='+str(yr))
        d = xbmcgui.Dialog()
        video_menu = d.select("Wybierz Rok", tab)
        self.control.log('filmdom wybrales [%s]' % video_menu)

        if video_menu != -1:
            return tab2[video_menu]
        else:
            return None
        #    self.control.log('%s' % str(i))
            #myurl = catUrl  % i[1]
        #    myurl = href[i]
        #    self.add(self.host, 'categories-menu', years[i],years[i],  'None', myurl, True, False)
        #xbmcplugin.endOfDirectory(int(sys.argv[1]))
        #self.control.directory(int(sys.argv[1]))


    def listsSearchResults(self, key):
        self.control.log(key)
        post_data = {'search': key}
        result = self.s.post(szukajUrl, data=post_data).text
        #self.control.log('ALA %s' % result.encode('utf-8'))
        try:
            result = re.findall('<h2 class="headline">Filmy</h2>(.*)<h2 class="headline">Seriale</h2>', result, re.DOTALL)[0]
            r = self.client.parseDOM(result, 'div', attrs={'class':'item-block clearfix'})
            r = [(self.client.parseDOM(i, 'a', ret='href'),
                  self.client.parseDOM(i, 'img', ret='src'),
                  self.client.parseDOM(i, 'h3'),
                  self.client.parseDOM(i, 'p')) for i in r]
            for i in r:
                self.control.log('ALA %s' % str(i))
                 # self.control.log('%s' % str(i) )
                try:
                    # self.control.log('AAA %s' % str(i))
                    meta = {'title': i[2][0], 'poster': i[1][0], 'year': '','plot': i[3][0]}
                    meta['originaltitle'] = i[2][0].encode('utf-8')
                    params = {'service': self.host, 'name': 'playselectedmovie', 'category': '', 'isplayable': 'true',
                              'url': i[0][0]}
                    params.update(meta)
                    self.add2(params)
                except Exception as e:
                    self.control.log('EEEEEEEEERRRTOO %s' % e)
                    pass
        except:
            pass
        self.dirend(int(sys.argv[1]))

    def listsItems(self, url):


    #<span style="background-color: #cc8226;" class="page-number page-numbers current">1</span>
        try:
            mypagenumber = re.findall('=(\d+)',url)[0]
            page = int(mypagenumber)
        except:
            page = 1
        self.control.log('[]1 %s' % url)
        self.control.log('[]1 %s' % page)
       # mynext = url.replace('='+str(page), '='+str(page+1))
       # self.control.log('[]2 %s' % mynext)

        '''
        <div class="film_content">\n
          <div class="film_image">\n
            <a href="http://filmdom.pl/films/gadajace-glowy/">
            <img class="img-responsive" src="http://filmdom.pl/assets/uploads/2018/03/7247038.3-200x285.jpg" alt="Gadaj\u0105ce g\u0142owy" title="Gadaj\u0105ce g\u0142owy"></a>\n
          <span class="accent_btn film_quality">6</span>\n<span class="accent_btn film_year">1980</span>     \n
          <h3 class="film_title"><a href="http://filmdom.pl/films/gadajace-glowy/">Gadaj\u0105ce g\u0142owy</a>
          </h3>\n<span class="last_modification">Ostatnia modyfikacja: <br />17-03, 20:47\n</span>\n
          </div>\n<
          div class="film_buttons">\n<a rel="nofollow" href="http://filmdom.pl/films/gadajace-glowy/">
          <div class="btn btn-primary play">Ogl\u0105daj</div></a>\n</div>\n</div>\n

        '''
        #link = self.client.request(url)
        result = self.request(url, utf=False)
        print "~~~URL: ", repr(url)
        print "~~~Filmdom->Strona: ",repr(result)

        #<ul class="pagination">
        pagination=self.client.parseDOM(result,'ul',attrs={"class": "pagination"})
        print "pagination: " + repr(pagination)
        currentpage=self.client.parseDOM(pagination,'span',attrs={"class": "page-number page-numbers current"})
        pages=self.client.parseDOM(pagination,'a',ret='href')
        allfilms = self.client.parseDOM(result,'div', attrs={"class": "films"})
        subfilms = self.client.parseDOM(result,'div', attrs={"class": "film_content"})
        grp = {}
        for i in range(0, len(subfilms)):
            grp['image'] = self.client.parseDOM(subfilms[i],'img', ret='src')
            grp['title'] = self.client.parseDOM(subfilms[i],'img', ret='title')
            grp['href'] = self.client.parseDOM(subfilms[i],'a', ret='href')[0]
            grp['year'] = self.client.parseDOM(subfilms[i],'span',attrs={"class": "accent_btn film_year"})

            print "Href: ", repr(grp['href'])

            try:
                meta = {'title': grp['title'][0], 'poster': grp['image'][0], 'year': grp['year'][0],'plot': 'plot', 'orginaltitle':grp['title'][0]}
                params = {'service': self.host, 'name': 'playselectedmovie', 'category': '','isplayable': 'true','url': grp['href']}
                params.update(meta)
                self.add2(params)
            except Exception as e:
                self.control.log('filmdom-1 ITEM ADD ERROR %s' % e)
                pass


        if len(pages)>-1 and currentpage:
            print "pages: ", repr(pages)
            print "VAL: " +  currentpage[0]
            #http://filmdom.pl/films/page/2/?search_active=1&yearOd=1950&yearDo=2018&gatunkis%5B0%5D=Akcja&gatunkis%5B1%5D=Ba%C5%9B%C5%84
            mynext=pages[0+int(currentpage[0])]
            self.add(self.host, 'categories-menu', u'Następna strona ('+str(int(currentpage[0])+1)+')',u'Następna strona ('+str(int(currentpage[0])+1)+')',  'None', mynext, True, False)
        #print "hmm1: ",repr(tst)
        #tst2 = self.client.parseDOM(tst,'article', attrs={"class": "item movies"})
        #print "hmm: ",repr(tst2)
        #for b in range(0, len(tst2)):
        #    group = {}
        #    poster =  self.client.parseDOM(tst2[b], "div",attrs={"class": "poster"})
        #    print "Poster: ",repr(poster)
        #    image=self.client.parseDOM(poster,'img',ret='src')
        #    datafeat = self.client.parseDOM(tst2[b],"div",attrs={"class": "data dfeatur"})
        #    print "Datafeat: ",repr(datafeat)
        #    title=self.client.parseDOM(datafeat,'a')
        #    href=self.client.parseDOM(datafeat,'a',ret='href')
        #    year=self.client.parseDOM(datafeat,'span')

        #    print "Title: ",title, " img: ",image, " href: ",href

        #    try:
        #        meta = {'title': title[0], 'poster': image[0], 'year': year[0],'plot': 'plot', 'orginaltitle':'title'}
        #        params = {'service': self.host, 'name': 'playselectedmovie', 'category': '','isplayable': 'true','url': href[0]}
        #        params.update(meta)
        #        self.add2(params)
        #    except Exception as e:
        #        self.control.log('cdaxf-1 ITEM ADD ERROR %s' % e)
        #        pass
        #r = self.client.parseDOM(result,'div', {"class": "col-xs-6 col-sm-3 col-lg-3"})
        #r = [(self.client.parseDOM(i, 'a', ret='href'),self.client.parseDOM(i, 'img', ret='src'),
        #      self.client.parseDOM(i, 'a', ret='data-content'),self.client.parseDOM(i, 'div', attrs={'class': 'year'}),
        #      self.client.parseDOM(i, 'div', attrs={'class': 'title'})) for i in r]

        #for i in r:
        #    self.control.log('%s' % str(i))
        #    try:
        #        tite = i[4][0].split('/')[1]
        #        titp = i[4][0].split('/')[0]
        #    except:
        #        tite = i[4][0]
        #        titp = i[4][0]
        #    try:
        #        meta = {'title': titp, 'poster': i[1][0], 'year': i[3][0],'plot': i[2][0], 'orginaltitle':tite}
        #        params = {'service': self.host, 'name': 'playselectedmovie', 'category': '','isplayable': 'true','url': i[0][0]}
        #        params.update(meta)
        #        self.add2(params)
        #    except Exception as e:
        #        self.control.log('cdaxf-1 ITEM ADD ERROR %s' % e)
        #        pass

        #self.add(self.host, 'categories-menu', u'Następna strona',u'Następna strona',  'None', mynext, True, False)
        self.dirend(int(sys.argv[1]))

    def listsItems2(self, url):
        result = self.request(url, utf=False)
        try:
            pagestrona=self.client.parseDOM(result,'div',attrs={"class": "pagination"})
            mypage=self.client.parseDOM(result,'span',attrs={"class": "current"})
            #mypagenumber = re.findall('=(\d+)',url)[0]
            page = int(mypage[0])
        except:
            page = 1
        self.control.log('[]1 %s' % url)
        self.control.log('[]1 %s' % page)

        if re.search('page',url):
            mynext=url.replace('/'+str(page), '/'+str(page+1))
        else:
            mynext = url + "page/"+str(page+1)+"/"
            print "nexturl: ",repr(mynext)
       # self.control.log('[]2 %s' % mynext)

        #link = self.client.request(url)
        #result = self.request(url, utf=False)
        print "Strona: ",repr(result)
        tst = self.client.parseDOM(result,'div', attrs={"class": "items"})
        print "hmm1: ",repr(tst)
        tst2 = self.client.parseDOM(tst,'article', attrs={"class": "item movies"})
        print "hmm: ",repr(tst2)
        for b in range(0, len(tst2)):
            group = {}

            poster =  self.client.parseDOM(tst2[b], "div",attrs={"class": "poster"})
            print "Poster: ",repr(poster)
            text=self.client.parseDOM(poster,'div',attrs={"class": "texto"})
            text=self.client.parseDOM(poster,'div')
            print "Testo: ",repr(text)
            image=self.client.parseDOM(poster,'img',ret='src')
            quality=self.client.parseDOM(poster,'span',attrs={"class": "quality"})

            data=self.client.parseDOM(tst2[b], "div",attrs={"class": "data"})
            href=self.client.parseDOM(data,'a',ret='href')
            title=self.client.parseDOM(data,'a')
            year=self.client.parseDOM(data,'span')
            #datafeat = self.client.parseDOM(tst2[b],"div",attrs={"class": "data dfeatur"})
            #print "Datafeat: ",repr(datafeat)
            #title=self.client.parseDOM(datafeat,'a')
            #href=self.client.parseDOM(datafeat,'a',ret='href')
            #year=self.client.parseDOM(datafeat,'span')

            print "Title: ",title, " img: ",image, " href: ",href, " year: ",year

            try:
                meta = {'title': title[0], 'poster': image[0], 'year': year[0],'plot': text[0], 'orginaltitle':'title'}
                params = {'service': self.host, 'name': 'playselectedmovie', 'category': '','isplayable': 'true','url': href[0]}
                params.update(meta)
                self.add2(params)
            except Exception as e:
                self.control.log('cdaxf-1 ITEM ADD ERROR %s' % e)
                pass
        #r = self.client.parseDOM(result,'div', {"class": "col-xs-6 col-sm-3 col-lg-3"})
        #r = [(self.client.parseDOM(i, 'a', ret='href'),self.client.parseDOM(i, 'img', ret='src'),
        #      self.client.parseDOM(i, 'a', ret='data-content'),self.client.parseDOM(i, 'div', attrs={'class': 'year'}),
        #      self.client.parseDOM(i, 'div', attrs={'class': 'title'})) for i in r]

        #for i in r:
        #    self.control.log('%s' % str(i))
        #    try:
        #        tite = i[4][0].split('/')[1]
        #        titp = i[4][0].split('/')[0]
        #    except:
        #        tite = i[4][0]
        #        titp = i[4][0]
        #    try:
        #        meta = {'title': titp, 'poster': i[1][0], 'year': i[3][0],'plot': i[2][0], 'orginaltitle':tite}
        #        params = {'service': self.host, 'name': 'playselectedmovie', 'category': '','isplayable': 'true','url': i[0][0]}
        #        params.update(meta)
        #        self.add2(params)
        #    except Exception as e:
        #        self.control.log('cdaxf-1 ITEM ADD ERROR %s' % e)
        #        pass

        self.add(self.host, 'categories-menu', u'Następna strona('+str(page+1)+')',u'Następna strona('+str(page+1)+')', 'None', mynext, True, False)
        self.dirend(int(sys.argv[1]))


    def getMovieLinkFromXML(self, url):
        print "What url: ", repr(url)

        moviepage = self.client.request(url)
        print "Filmy: ", repr(moviepage)

#        basefilm=self.client.parseDOM(link,'div',attrs={"class": "play-box-iframe fixidtab"})
#        print "Basefilm: ",repr(basefilm)
#        iframe=self.client.parseDOM(basefilm,'iframe',ret='src')
#        print "iframe: ",repr(iframe)
#        ctable=self.client.parseDOM(link,'div',attrs={"class": "links_table"})
#        print "ctable: ", repr(ctable)
#        subtable=self.client.parseDOM(link,'tbody')
#        print "subtable: ", repr(subtable)
#        links=self.client.parseDOM(ctable,'a',ret='href')
#        images=self.client.parseDOM(ctable,'img',ret='src')
#        text=self.client.parseDOM(ctable,'a')
#        trs=self.client.parseDOM(subtable,'tr',ret='id')
#        print "images: ", repr(trs)
        #<tbody id="all-links">
        #r = [(self.client.parseDOM(i, 'a', ret='href'),self.client.parseDOM(i, 'img', ret='src'),
        #      self.client.parseDOM(i, 'a', ret='data-content'),self.client.parseDOM(i, 'div', attrs={'class': 'year'}),
        #      self.client.parseDOM(i, 'div', attrs={'class': 'title'})) for i in r]

        linknames=self.client.parseDOM(moviepage,'tbody',attrs={"id": "all-links"})
        linknames=self.client.parseDOM(linknames,'tr')
        linknames=[(self.client.parseDOM(i,'td')) for i in linknames]


        subset = self.client.parseDOM(moviepage,'script')

        for i in subset:
            if re.search("var PublicLink",i):
                linkset=i

        linkset=linkset[19:-2]
        linkset=re.sub('"','',linkset)
        linkset=linkset.replace('\\','')
        movielinks=re.split(',',linkset)

        #r = self.client.parseDOM(link, 'tr')

        #r = [(self.client.parseDOM(i, 'a', ret='href'),
        #      self.client.parseDOM(i, 'img', ret='alt'),
        #      self.client.parseDOM(i, 'td')
        #      ) for i in r]

        #r = [(i[0][0], i[1][0], i[2][0], i[2][1]) for i in r if len(i[0]) > 0]

        #for i in r:
        #    self.control.log('%s' % str(i))

        tab = []
        tab2 = []

        for i in range(len(movielinks)):
            tab.append(linknames[i][3] + ' ('+linknames[i][1]+' - '+linknames[i][2]+')')
            tab2.append(movielinks[i])
#        if len(iframe)>-1:
#            tab.append('Default Player')
#            tab2.append(iframe[0])
        #for i in r:
        #for i in range(0, len(links)):
        #    self.control.log("Link ALL %s" % str(i))
        #    #tab.append(i[1] + ' - ' + i[2]+ ' - ' + i[3])
        #    tds=self.client.parseDOM(subtable,'tr',attrs={"id": trs[i]})
        #    detale=self.client.parseDOM(tds,'td')
        #    print "Append image: ", images[i]
        #    gethost=images[i].split("=")
        #    tab.append(gethost[1] + ' (Jakosc: ' + detale[1] + ' - ' + detale[2] + ')')
        #    tab2.append(links[i])
        d = xbmcgui.Dialog()
        video_menu = d.select("Wybór strony video", tab)
        self.control.log('filmdom wybrales [%s]' % video_menu)

        if video_menu != -1:
            linkVideo = tab2[video_menu]
            if 'cda-x.pl/links' in linkVideo:
                link = self.request(linkVideo)
                print "linker: ",repr(link)
                #match = re.search('<a href="(.*?)" class="btn btn-primary">Link do strony z video</a>', link)
                match = re.search('<meta name="og:url"',link)
                if match:
                    linkVid = self.client.parseDOM(link,'meta',attrs={"name": "og:url"},ret='content')
                    linkVideo=linkVid[0]

                    print "taki link: ",linkVideo
                    #linkVideo = match.group(1).split('http')[-1]
                    #linkVideo = 'http' + linkVideo
                    self.control.log('GRR  [%s]' % str(linkVideo))
            self.control.log('2 All pageparser   YXYXYYX   PLAYYYYYYERRRRRRRRRRRR [%s]' % linkVideo)
            #linkVideo = self.up.getVideoLink(tab2[video_menu], url)
            print "what resolve: ", linkVideo
            return self.urlresolve(linkVideo)
        else:
            return None


    def sub_handleService(self, params):
        name = params["name"]
        category = params["category"]

        url = params["url"]

        if name == 'main-menu' and category == 'Polecane':
            self.control.log('Jest Polecane: ')
            self.listsItems(polecaneUrl)
        if name == 'main-menu' and category == 'Polskie':
            self.control.log('Jest Polskie: ')
            self.listsItems(polskieUrl)
        if name == 'main-menu' and category == 'DlaDzieci':
            self.control.log('Jest dla dziecie: ')
            self.listsItems(dladzieciUrl)
        elif name == 'main-menu' and category == 'Kategorie':
            self.control.log('Jest Kategorie: ')
            self.listsCategoriesMenu()
        elif name == 'main-menu' and category == 'Rok':
            self.control.log('Jest Rok: ')
            #self.listsYearMenu()
            data = self.listsYearMenu()
            print "DAT: " + repr(data)
            if data != None:
                self.listsItems(data)
        elif name == 'categories-menu':
            self.control.log('Jest categories-menu: ')
            self.listsItems(url)





