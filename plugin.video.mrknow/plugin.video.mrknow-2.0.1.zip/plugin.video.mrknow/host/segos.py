# -*- coding: utf-8 -*-


'''
    plugin.video.mrknow XBMC Addon
    Copyright (C) 2017 mrknow

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
'''
import sys, urlparse
import re
from __generic_host__ import GenericHost
import xbmcgui

from resources.lib.libraries import control
from resources.lib.libraries import client

mainurl='https://segos.es/'
filmyUrl='https://segos.es/?page=filmy'
lastadded = '/?page=filmys'
lastadded2 = '/?page=filmy'
bajki = '/bajki.php'
szukaj = '/?search=%s'

HOST = {'User-Agent': 'Specto for Kodi'}
headers = {'User-Agent': 'Specto for Kodi', 'ContentType': 'application/x-www-form-urlencoded'}
myheaders = {'User-Agent': 'Specto for Kodi', 'ContentType': 'application/x-www-form-urlencoded'}

class Segos(GenericHost):
    scriptname = 'Segos'
    host = 'segos'
    MENU_TAB = [
        {'id': 1, 'title': 'Top 10', 'mod': 'ListTop10'},
        {'id': 2, 'title': 'Ostatnio dodane', 'mod': 'ListNowe'},
        {'id': 3, 'title': 'Gatunki', 'mod': 'ListGatunki'},
        {'id': 4, 'title': 'Bajki', 'mod': 'ListBajki', },
        {'id': 5, 'title': 'Szukaj', 'mod': 'find', },
        {'id': 6, 'title': 'Historia wyszukiwania', 'mod': 'history'},

    ]

    def segosLogin(self):
        print "we are in login mode"
        try:
            params={}

            params['login']='zaloguj'
            params['user_name'] = 'mr.rumcajz'
            params['user_password'] = 'sylwia2006'

            #login to site

            result, headers, content, cookie = self.client.request('https://segos.es/', post=params, headers=myheaders, output='extended')
            control.set_setting('segos.token', cookie)
            print "LOGIFN: ", repr(result)
            return True
        except Exception as e:
            print "Really not trying?"
            control.log('Error segos.login %s' % e)
        return False

    def ListMovies(self, url):
        result = self.client.request(urlparse.urljoin(mainurl, url))
        r = self.client.parseDOM(result, 'div', attrs={'class': 'well'})[0]
        r = self.client.parseDOM(r, 'div', attrs={'class': 'col-lg-12 col-md-12 col-xs-12'})
        for i in r:
            self.control.log('a %s' % i.encode('ascii', 'ignore'))
        r = [(self.client.parseDOM(i, 'div', attrs={'Style':'text-align: center;margin-top: 5px;'}),
              self.client.parseDOM(i, 'img', attrs={'class':'img-responsive img-home-portfolio img-glowna'}, ret='src')) for i in r]
        r = [(self.client.parseDOM(i[0], 'a', ret='href'),self.client.parseDOM(i[0], 'a'),i[1]) for i in r]
        r = [(i[0][0], i[1][0].encode('utf-8'), i[2][0]) for i in r if len(i[1]) > 0 and len(i[2]) > 0]

        for i in r:
            img = i[2]
            if not img.startswith('http'):
                img = urlparse.urljoin(mainurl, img)
            meta = {'title': i[1], 'poster': img, 'originaltitle': i[1]}
            params = {'service': self.host, 'name': 'playselectedmovie', 'category': '', 'isplayable': 'true','url':  i[0]}
            params.update(meta)
            self.add2(params)

        r2 = re.findall('<li class="active"><a href=".*?">.*?</a></li><li><a href="(.*?)">.*?</a>',result)
        if r2:
            self.control.log('XXXX' + str(r2))
            self.add(self.host, 'items-menu', 'ListMovies', 'Następna', 'None', r2[0], True, False)

        self.dirend(int(sys.argv[1]))

    def ListTop10(self, url):
        result = self.client.request(url)
        print "url: "+ repr(url)
        #print "outpytl:  " + repr(result)
        top10block = self.client.parseDOM(result, 'div', attrs={'class': 'well'})[3]
        #print "top10block"  + repr(top10block)
        top10list = [(self.client.parseDOM(top10block,'div',attrs={"style": "float: left;width: 60px;height: 60px;margin-bottom: 10px;"}),
                      self.client.parseDOM(top10block,'a',ret='href'),self.client.parseDOM(top10block,'a'))]
        #sublist = self.client.parseDOM(top10block,'div',attrs={"style": "margin: 0 0 1px 70px; background-image: url(/images/medal.png); background-repeat: no-repeat; background-size: 29px; background-position-x: right; background-position-y: 0px;"})
        print "top10: " + repr(top10list)


        print "range block list: " + repr(len(top10list))
        print "sub block" + repr(len(top10list[0]))
        #print "sublist: " + repr(sublist)
        grp={}

        for i in range(len(top10list[0][0])):
            grp['image']=self.client.parseDOM(top10list[0][0][i],'img',attrs={"width": "60"},ret='src')
            print "Image: " + repr(grp['image'])
            grp['href']=urlparse.urljoin(mainurl,top10list[0][1][i])
            print "href: " + repr(grp['href'])
            grp['title']=top10list[0][2][i]
            print "title: " + repr(grp['title'])
            if not grp['image'][0].startswith('http'):
                grp['image'][0] = urlparse.urljoin(mainurl, grp['image'][0])
            meta = {'title': grp['title'], 'poster': grp['image'][0], 'originaltitle': grp['title']}
            params = {'service': self.host, 'name': 'playselectedmovie', 'category': '', 'isplayable': 'true','url': grp['href']}
            params.update(meta)

            print "ListTop10 --> params to add: " + repr(params)
            self.add2(params)
        #r = self.client.parseDOM(r, 'div', attrs={'class': 'col-lg-12 col-md-12 col-xs-12'})
        '''
        for i in r:
            self.control.log('a %s' % i.encode('ascii', 'ignore'))
        r = [(self.client.parseDOM(i, 'div', attrs={'Style':'text-align: center;margin-top: 5px;'}),
              self.client.parseDOM(i, 'img', attrs={'class':'img-responsive img-home-portfolio img-glowna'}, ret='src')) for i in r]
        r = [(self.client.parseDOM(i[0], 'a', ret='href'),self.client.parseDOM(i[0], 'a'),i[1]) for i in r]
        r = [(i[0][0], i[1][0].encode('utf-8'), i[2][0]) for i in r if len(i[1]) > 0 and len(i[2]) > 0]

        for i in r:
            img = i[2]
            if not img.startswith('http'):
                img = urlparse.urljoin(mainurl, img)
            meta = {'title': i[1], 'poster': img, 'originaltitle': i[1]}
            params = {'service': self.host, 'name': 'playselectedmovie', 'category': '', 'isplayable': 'true','url':  i[0]}
            params.update(meta)
            self.add2(params)

        r2 = re.findall('<li class="active"><a href=".*?">.*?</a></li><li><a href="(.*?)">.*?</a>',result)
        if r2:
            self.control.log('XXXX' + str(r2))
            self.add(self.host, 'items-menu', 'ListMovies', 'Następna', 'None', r2[0], True, False)
        '''
        self.dirend(int(sys.argv[1]))

    def pagination(self,source):
        grp={}
        grp['prevpage'] = None
        grp['nextpage'] = None
        pagsource=client.pareDOM(source,'nav',attrs={"class": "paginacja"})
        currpagesrc=client.parseDOM(pagsource,'li',attrs={"class": "active"})
        currpage=client.parseDOM(currpagesrc,'a',ret='href')
        allpages=[client.parseDOM(pagsource,'a',ret='href'),client.parseDOM(pagsource,'a')]

        if len(allpages[0])>int(currpage)+1:
            grp['nextpage']=allpages[0][int(currpage)]
        if int(currpage)>1:
            grp['prevpage']=allpages[0][int(currpage)-1]

        return grp

    def ListMovies1(self, url):
        print "The URL: " + repr(url)
        result = self.client.request(urlparse.urljoin(mainurl, url))
        #pagegroup = pagination(result)
       # print "ListMovies(on): ", repr(result)
        well = self.client.parseDOM(result, 'div', attrs={'class': 'well'})[0]
        print "well: " + repr(well)
        myclasses = self.client.parseDOM(well, 'div', attrs={'class': 'col-lg-12 col-md-12 col-xs-12'})

        print "range of class: " + repr(len(myclasses))
        print "myclasses: " + repr(myclasses)
        #images=[]
        #href=[]
        #title=[]
        #plot=[]
        for i in range(0,len(myclasses)):

            images1=self.client.parseDOM(myclasses[i], 'img', attrs={'class': 'img-responsive'}, ret='src')
            href1=self.client.parseDOM(myclasses[i], 'a', ret='href')
            title1=self.client.parseDOM(myclasses[i], 'a')[1]
            myString=myclasses[i]
            print "MyString: ", repr(myString)
            newstring=myString[myString.find('Opis')+10:len(myString)]
            newstring=newstring[0:newstring.find('<br ')]
            print "NewString: ", repr(newstring)
            plot1=newstring.encode('utf-8')

            #href1=href1.replace('&','||')
            print "My href: ", repr(href1[0])

            #if not img.startswith('http'):
            #     = urlparse.urljoin(mainurl, img)
            print "Adding url: ", repr(href1[0])
            meta = {'title': title1, 'poster': images1[0], 'plot': plot1, 'originaltitle': title1}
            params = {'service': self.host, 'name': 'playselectedmovie', 'category': '', 'isplayable': 'true','url':  href1[0]}
            params.update(meta)
            self.add2(params)

            #plot.append(self.client.parseDOM(myclasses[i],'Opis</b>: '))
        r2 = re.findall('<li class="active"><a href=".*?">.*?</a></li><li><a href="(.*?)">(.*?)</a>',result)
        if r2:
            self.control.log('XXXX' + str(r2))
            self.add(self.host, 'items-menu', 'ListMovies1', 'Następna ('+r2[0][1]+')', 'None', r2[0][0], True, False)
      #  print "Images: ", repr(images)
      #  print "Href: ", repr(href)
      #  print "Title: ", repr(title)
        #print "Plot: ", repr(plot)
        #r = self.client.parseDOM(result, 'div', attrs={'class': 'well'})[0]
        #r = self.client.parseDOM(r, 'div', attrs={'class': 'col-lg-3 col-md-3 col-sm-6 segos'})
        #r = [(self.client.parseDOM(i, 'a', ret='href'),
        #      self.client.parseDOM(i, 'div', attrs={'style':'text-align:center;padding-top:7px;'}),
        #      self.client.parseDOM(i, 'img', attrs={'class':'img-responsive img-home-portfolio img-glowna'}, ret='src')) for i in r]
        #for i in r:
        #    self.control.log('aaa'+str(i))

        #r = [(i[0],i[1],i[2]) for i in r]
        #r = [(i[0][0], i[1][0].encode('utf-8'), i[2][0]) for i in r if len(i[1]) > 0 and len(i[2]) > 0]
            #                                                                             \
       # for i in r:
       #     img = i[2]
       #     if not img.startswith('http'):
       #         img = urlparse.urljoin(mainurl, img)
       ##     meta = {'title': i[1], 'poster': img, 'originaltitle': i[1]}
       #     params = {'service': self.host, 'name': 'playselectedmovie', 'category': '', 'isplayable': 'true','url':  i[0]}
       #     params.update(meta)
       #     self.add2(params)


      #  r2 = re.findall('<li class="active"><a href=".*?">.*?</a></li><li><a href="(.*?)">.*?</a>',result)
      #  if r2:
      #      self.control.log('XXXX' + str(r2))
      #      self.add(self.host, 'items-menu', 'ListMovies1', 'Następna', 'None', r2[0], True, False)

        self.dirend(int(sys.argv[1]))

    def listsSearchResults(self, key):

        self.ListMovies1(szukaj % key)
        #url = szukaj % key
        #result = self.client.request(urlparse.urljoin(mainurl, url))
        #r = self.client.parseDOM(result, 'p', attrs={'style':'padding-top.+?'})
        #r = [(self.client.parseDOM(i, 'a', ret='href')[0], self.client.parseDOM(i, 'a')[0]) for i in r]
        #for i in r:
        #    title = i[1].encode('utf-8').replace('<img src="/img/hd.png">','')
        #    # (self, service, name, category,               title, iconimage, url, desc, rating, folder = True, isPlayable = True):
        #    self.add(self.host,  'playselectedmovie', 'None', title, 'None', i[0], False, True)
        #self.dirend(int(sys.argv[1]))

    def ListGatunki(self):

        if self.segosLogin():
            cookie = control.setting('segos.token').strip()
        else:
            print "Hmm"
            #ref='http://wizja.tv/watch.php?id=%s' % id
            #result =  client.request(ref, headers=HOST, cookie=cookie)
            #HOST['Referer']=ref
            #url = 'http://wizja.tv/porter.php?ch=%s' % id
            #result =  client.request(url, headers=HOST, cookie=cookie)

        main_result = self.client.request(urlparse.urljoin(mainurl, lastadded2))
        print "Gatunki result: " + repr(main_result)
        well_subset=self.client.parseDOM(main_result,'div',attrs={"class": "well"})

        #print "Well subset: ",repr(well_subset)
        for i in well_subset:
            if re.search("<h4>Kategorie</h4>",i):
                categories_subset=i

        categories_href=self.client.parseDOM(categories_subset,'a',ret='href')
        categories_name=self.client.parseDOM(categories_subset,'a')

        print "HREF: ",repr(categories_href)
        print "NAME: ",repr(categories_name)

        for b in range(0, len(categories_name)):
            #test1=categories_name[b].decode('utf-8')
            #test1.decode("utf-8")
            #print "prefoo: ",repr(categories_name[b])
            #print "foo: ",categories_name[b].encode('utf-8')
            #test2=categories_href[b].decode("utf-8").encode("ISO-8859-2")
            #print "Segos Categorytest: " + test1 + " -- " + test2
            print "Segos Category: " + categories_name[b].encode('utf-8') + " -- " + categories_href[b].encode('utf-8')
            #print "foo"
            #self.add3(self.host, 'items-menu', 'ListMovies1', categories_name[b].encode('utf-8'), 'None', categories_href[b].encode('utf-8'), True, False)
            self.add(self.host, 'items-menu','ListMovies1', categories_name[b].encode('utf-8'), 'None', urlparse.urljoin(mainurl,categories_href[b].encode('utf-8')), True, False)
#        print "result: ",repr(kategorie)
#        r2 = re.findall('<li><a href="(/filmy/gatunek.php\?gatunek=.*?)">(.*?)</a></li>', result)
#        self.control.log('ZXZX' + str(r2))

#        if r2:
#            self.control.log('ZXZX'+str(r2))
#            for i in enumerate(r2):
#                self.control.log('ZXZX' + str(i[1][0]))
#                self.add(self.host, 'items-menu', 'ListMovies1', i[1][1], 'None', i[1][0], True, False)
        self.control.directory(int(sys.argv[1]))



    def getMovieLinkFromXML(self, url):
       # try:
            print "Jaki url:" + repr(url)
            result = self.client.request(urlparse.urljoin(mainurl, url))
            print "MovieLinks: ", repr(result)
            print "urls: ",repr(url),repr(mainurl)

            block = self.client.parseDOM(result,'div',attrs={"style": "overflow: auto;"})
            print "ffin block: " + repr(block)
            #table = self.client.parseDOM(block,'tr')
            table = self.client.parseDOM(block,'tbody')
            hreflist = client.parseDOM(table,'a',ret='href')
            serverlist=client.parseDOM(table,'img',attrs={"style": "max-width: 100px;"},ret='src')
            access = self.client.parseDOM(table,'td',attrs={"style": "text-align: center; vertical-align: middle;"})
            #access = "(Dostep: " + access.strip()+")"
            #access = access.decode('utf-8')
            #table = self.client.parseDOM(table,'tr')
            print "ffin access: " + repr(access)
            print "ffin table: " +repr(table)
            grp={}

            print "length of table: " + repr(len(table))
            for i in range(len(table)):
            #    access = self.client.parseDOM(table,'td',attrs={"style": "text-align: center; vertical-align: middle;"})[4]
            #    access = "(Dostep: " + access.strip()+")"
            #    access = access.decode('utf-8')
                print "ello" + repr(i)
                grp['servers']=self.client.parseDOM(table[i],'select',attrs={"class": "form-control", "name": "server"})
                print "servers: " + repr(grp['servers'])
                grp['servers']=self.client.parseDOM(grp['servers'],'option')
                print "href: " + repr(grp['servers'])

            tab = []
            tab2 = []
            srvcnt = 0;
            print "serverlist: " + repr(len(serverlist))
            print "hreflist: " + repr(len(hreflist))
            accessid=4
            for i in range(len(hreflist)):
                print "its time: " + repr(hreflist[i])

                if re.search("page=filmy",hreflist[i]):
                #accessid+=6
                    #print "adding: " + repr(hreflist[i]) + "--> " + str(srvcnt)
                    #pagesource=self.client.request(urlparse.urljoin(mainurl,hreflist[i]))
                    #iframe=self.client.parseDOM(pagesource,'iframe',ret='src')
                   # if iframe:
                   mserver=serverlist[srvcnt].split("/")
                   #   print "fuck " + repr(iframe)
                   mserver= mserver[-1]
                   mserver=mserver.split(".")
                   #   tab.append(mserver[0])
                   #   tab2.append(iframe[0])
                   accesstxt=" (Dostep: "+access[accessid].strip()+")"
                   accessid+=6
                   tab.append(mserver[0] + accesstxt)
                   print "getMovieLinkFromXML --> tab2append: " + repr(urlparse.urljoin(mainurl,hreflist[i]))
                   tab2.append(urlparse.urljoin(mainurl,hreflist[i]))
                   srvcnt+=1

            d = xbmcgui.Dialog()
            video_menu = d.select("Wybór strony video", tab)
            if video_menu != -1:
                linkVideo = tab2[video_menu]

                pagesource=self.client.request(linkVideo)
                iframe=self.client.parseDOM(pagesource,'iframe',ret='src')

                if iframe:
                    linkVideo = iframe[0]
                else:
                   # linkVideo = None
                    return None
                      #mserver=serverlist[srvcnt].split("/")
                      #print "fuck " + repr(iframe)
                      #mserver= mserver[-1]
                      #mserver=mserver.split(".")

                #print "What linl: " + repr(linkVideo)
              #if 'cda-x.pl/links' in linkVideo:
              #  link = self.request(linkVideo)
              #  print "linker: ",repr(link)
              #  #match = re.search('<a href="(.*?)" class="btn btn-primary">Link do strony z video</a>', link)
              #  match = re.search('<meta name="og:url"',link)
              #  if match:
              #      linkVid = self.client.parseDOM(link,'meta',attrs={"name": "og:url"},ret='content')
              #      linkVideo=linkVid[0]
              #
              #      print "taki link: ",linkVideo
              #      #linkVideo = match.group(1).split('http')[-1]
              #      #linkVideo = 'http' + linkVideo
              #      self.control.log('GRR  [%s]' % str(linkVideo))
              #  if re.search("boton reloading",link):
              #      linkVid = self.client.parseDOM(self.client.parseDOM(link,'div',attrs={"class": "boton reloading"}),'a',ret='href')
              #      linkVideo=linkVid[0]
              #  self.control.log('2 All pageparser   YXYXYYX   PLAYYYYYYERRRRRRRRRRRR [%s]' % linkVideo)
              #  #linkVideo = self.up.getVideoLink(tab2[video_menu], url)
              #  print "what resolve: ", linkVideo
                #print "getMovieLinkFromXML --> linkVideo: " + repr(linkVideo)
                return self.urlresolve(linkVideo)


            else:
                return None

                #"getting utrl: " + repr(grp['href'])
                #if re.search('class="form-control" name="server"',table[i]):
                #    vidopt=self.client.parseDOM(table[i],'select',attrs={"class": "form-control"})
                #    options=self.client.parseDOM(vidopt,'option')

           # r = self.client.parseDOM(result, 'a', attrs={'target': '_blank'}, ret='href')[0]
           # self.control.log(str(r))
           # return self.urlresolve(r)
           # linkVideo = False
           # return linkVideo
        #except:
         #   return None

    def sub_handleService(self, params):
        name = self.parser.getParam(params, "name")
        category = self.parser.getParam(params, "category")
        url = self.parser.getParam(params, "url")
        title = self.parser.getParam(params, "title")
        icon = self.parser.getParam(params, "icon")
        if category=='ListNowe':
            self.ListMovies(lastadded)

        elif category == 'ListTop10':
            self.ListTop10(filmyUrl)
        elif category == 'ListMovies':
            self.ListMovies(url)
        elif category == 'ListMovies1':
            self.ListMovies1(url)
        elif category == 'ListBajki':
            self.ListMovies(bajki)
        elif category == 'ListGatunki':
            self.ListGatunki()

        else:
            self.control.log('AAAAAAAAAAAA')

